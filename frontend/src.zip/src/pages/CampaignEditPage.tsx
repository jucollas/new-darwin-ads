import { useParams, useNavigate, Link } from "react-router-dom"
import { useQuery, useMutation } from "@tanstack/react-query"
import { queryClient } from "@/lib/queryClient"
import api from "@/lib/api"
import { toast } from "sonner"
import { useForm } from "react-hook-form"
import { zodResolver } from "@hookform/resolvers/zod"
import { z } from "zod"
import { ChevronRight, Loader2 } from "lucide-react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Textarea } from "@/components/ui/textarea"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Skeleton } from "@/components/ui/skeleton"
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select"
import type { Campaign } from "@/types"

const campaignSchema = z.object({
  name: z.string().min(3, "El nombre debe tener al menos 3 caracteres"),
  description: z.string().min(1, "La descripcion es requerida"),
  objective: z.enum(["traffic", "conversion", "reach"]),
  audience: z.string().min(1, "La audiencia es requerida"),
  dailyBudget: z.coerce.number().min(1, "El presupuesto debe ser mayor a 0"),
  whatsappNumber: z.string().min(1, "El numero de WhatsApp es requerido"),
})

type CampaignFormValues = z.infer<typeof campaignSchema>

const objectiveLabels: Record<string, string> = {
  traffic: "Trafico",
  conversion: "Conversion",
  reach: "Alcance",
}

export default function CampaignEditPage() {
  const { campaignId } = useParams<{ campaignId: string }>()
  const navigate = useNavigate()

  const { data: campaign, isLoading } = useQuery<Campaign>({
    queryKey: ["campaign", campaignId],
    queryFn: () => api.get(`/api/campaigns/${campaignId}`).then((r) => r.data),
  })

  const {
    register,
    handleSubmit,
    setValue,
    watch,
    formState: { errors },
  } = useForm<CampaignFormValues>({
    resolver: zodResolver(campaignSchema),
    values: campaign
      ? {
          name: campaign.name,
          description: campaign.description,
          objective: campaign.objective,
          audience: campaign.audience,
          dailyBudget: campaign.dailyBudget,
          whatsappNumber: campaign.whatsappNumber,
        }
      : undefined,
  })

  const objectiveValue = watch("objective")

  const saveMutation = useMutation({
    mutationFn: (data: CampaignFormValues) =>
      api.patch(`/api/campaigns/${campaignId}`, data),
    onSuccess: () => {
      toast.success("Campana actualizada correctamente")
      queryClient.invalidateQueries({ queryKey: ["campaign", campaignId] })
      queryClient.invalidateQueries({ queryKey: ["campaigns"] })
      navigate(`/campaigns/${campaignId}`)
    },
    onError: () => {
      toast.error("Error al guardar los cambios")
    },
  })

  const onSubmit = (data: CampaignFormValues) => {
    saveMutation.mutate(data)
  }

  if (isLoading) {
    return (
      <div className="max-w-2xl mx-auto space-y-6">
        <Skeleton className="h-8 w-48" />
        <Card>
          <CardContent className="space-y-4 pt-6">
            {Array.from({ length: 6 }).map((_, i) => (
              <Skeleton key={i} className="h-10 w-full" />
            ))}
          </CardContent>
        </Card>
      </div>
    )
  }

  if (!campaign) {
    return (
      <div className="flex flex-col items-center justify-center py-20">
        <p className="text-muted-foreground">Campana no encontrada</p>
        <Button variant="link" asChild>
          <Link to="/campaigns">Volver a campanas</Link>
        </Button>
      </div>
    )
  }

  return (
    <div className="max-w-2xl mx-auto space-y-6">
      {/* Breadcrumb */}
      <nav className="flex items-center gap-1 text-sm text-muted-foreground">
        <Link to="/campaigns" className="hover:text-foreground">
          Campanas
        </Link>
        <ChevronRight className="h-4 w-4" />
        <Link
          to={`/campaigns/${campaignId}`}
          className="hover:text-foreground"
        >
          {campaign.name}
        </Link>
        <ChevronRight className="h-4 w-4" />
        <span className="text-foreground">Editar</span>
      </nav>

      <h1 className="text-2xl font-bold">Editar campana</h1>

      <Card>
        <CardHeader>
          <CardTitle>Datos de la campana</CardTitle>
        </CardHeader>
        <CardContent>
          <form onSubmit={handleSubmit(onSubmit)} className="space-y-4">
            {/* Name */}
            <div className="space-y-2">
              <label htmlFor="name" className="text-sm font-medium">
                Nombre
              </label>
              <Input id="name" {...register("name")} />
              {errors.name && (
                <p className="text-sm text-destructive">
                  {errors.name.message}
                </p>
              )}
            </div>

            {/* Description */}
            <div className="space-y-2">
              <label htmlFor="description" className="text-sm font-medium">
                Descripcion
              </label>
              <Textarea id="description" rows={3} {...register("description")} />
              {errors.description && (
                <p className="text-sm text-destructive">
                  {errors.description.message}
                </p>
              )}
            </div>

            {/* Objective */}
            <div className="space-y-2">
              <label className="text-sm font-medium">Objetivo</label>
              <Select
                value={objectiveValue}
                onValueChange={(val) =>
                  setValue("objective", val as CampaignFormValues["objective"], {
                    shouldValidate: true,
                  })
                }
              >
                <SelectTrigger>
                  <SelectValue placeholder="Selecciona un objetivo" />
                </SelectTrigger>
                <SelectContent>
                  {Object.entries(objectiveLabels).map(([value, label]) => (
                    <SelectItem key={value} value={value}>
                      {label}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
              {errors.objective && (
                <p className="text-sm text-destructive">
                  {errors.objective.message}
                </p>
              )}
            </div>

            {/* Audience */}
            <div className="space-y-2">
              <label htmlFor="audience" className="text-sm font-medium">
                Audiencia
              </label>
              <Textarea
                id="audience"
                rows={3}
                placeholder="Describe tu audiencia objetivo..."
                {...register("audience")}
              />
              {errors.audience && (
                <p className="text-sm text-destructive">
                  {errors.audience.message}
                </p>
              )}
            </div>

            {/* Daily budget */}
            <div className="space-y-2">
              <label htmlFor="dailyBudget" className="text-sm font-medium">
                Presupuesto diario ($)
              </label>
              <Input
                id="dailyBudget"
                type="number"
                min={1}
                step="0.01"
                {...register("dailyBudget")}
              />
              {errors.dailyBudget && (
                <p className="text-sm text-destructive">
                  {errors.dailyBudget.message}
                </p>
              )}
            </div>

            {/* WhatsApp number */}
            <div className="space-y-2">
              <label htmlFor="whatsappNumber" className="text-sm font-medium">
                Numero de WhatsApp
              </label>
              <Input
                id="whatsappNumber"
                placeholder="+1234567890"
                {...register("whatsappNumber")}
              />
              {errors.whatsappNumber && (
                <p className="text-sm text-destructive">
                  {errors.whatsappNumber.message}
                </p>
              )}
            </div>

            {/* Actions */}
            <div className="flex justify-end gap-3 pt-4">
              <Button
                type="button"
                variant="outline"
                onClick={() => navigate(`/campaigns/${campaignId}`)}
              >
                Cancelar
              </Button>
              <Button type="submit" disabled={saveMutation.isPending}>
                {saveMutation.isPending && (
                  <Loader2 className="mr-1 h-4 w-4 animate-spin" />
                )}
                Guardar cambios
              </Button>
            </div>
          </form>
        </CardContent>
      </Card>
    </div>
  )
}
