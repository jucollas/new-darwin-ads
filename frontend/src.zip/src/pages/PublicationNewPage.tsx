import { useState } from "react"
import { useParams, useNavigate, Link } from "react-router-dom"
import { useQuery, useMutation } from "@tanstack/react-query"
import { queryClient } from "@/lib/queryClient"
import api from "@/lib/api"
import { toast } from "sonner"
import { useImageGeneration } from "@/hooks/useImageGeneration"
import {
  ChevronRight,
  Sparkles,
  Loader2,
  ArrowLeft,
  Image as ImageIcon,
  RefreshCw,
  Save,
  Send,
} from "lucide-react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Textarea } from "@/components/ui/textarea"
import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from "@/components/ui/card"
import { Skeleton } from "@/components/ui/skeleton"
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select"
import { ProposalCard } from "@/components/ProposalCard"
import type { Campaign, PublicationProposal } from "@/types"

type Step = 1 | 2 | 3

interface SelectedProposal extends PublicationProposal {
  copy: string
  dailyBudget: number
  whatsappNumber: string
}

export default function PublicationNewPage() {
  const { campaignId } = useParams<{ campaignId: string }>()
  const navigate = useNavigate()

  // Step state
  const [step, setStep] = useState<Step>(1)

  // Step 1 state
  const [prompt, setPrompt] = useState("")
  const [format, setFormat] = useState<"1:1" | "9:16">("1:1")
  const [platform, setPlatform] = useState<
    "facebook" | "instagram" | "tiktok"
  >("facebook")

  // Step 2 state
  const [proposals, setProposals] = useState<PublicationProposal[]>([])

  // Step 3 state
  const [selected, setSelected] = useState<SelectedProposal | null>(null)
  const [editCopy, setEditCopy] = useState("")
  const [editBudget, setEditBudget] = useState("")
  const [editWhatsapp, setEditWhatsapp] = useState("")

  const { generate: generateImage, imageUrl, isGenerating: imageGenerating, reset: resetImage } = useImageGeneration()

  const { data: campaign } = useQuery<Campaign>({
    queryKey: ["campaign", campaignId],
    queryFn: () => api.get(`/api/campaigns/${campaignId}`).then((r) => r.data),
  })

  // Generate proposals mutation
  const generateMutation = useMutation({
    mutationFn: () =>
      api
        .post("/api/campaigns/generate", {
          prompt,
          campaignId,
          format,
          platform,
        })
        .then((r) => r.data),
    onSuccess: (data: PublicationProposal[]) => {
      setProposals(data)
      setStep(2)
    },
    onError: () => {
      toast.error("Error al generar propuestas")
    },
  })

  // Regenerate single proposal
  const regenerateMutation = useMutation({
    mutationFn: (index: number) =>
      api
        .post("/api/campaigns/generate", {
          prompt,
          campaignId,
          format,
          platform,
          count: 1,
        })
        .then((r) => r.data),
    onSuccess: (data: PublicationProposal[], index: number) => {
      if (data.length > 0) {
        setProposals((prev) => {
          const next = [...prev]
          next[index] = data[0]
          return next
        })
      }
    },
    onError: () => {
      toast.error("Error al regenerar propuesta")
    },
  })

  // Save publication mutation
  const saveMutation = useMutation({
    mutationFn: (status: "draft" | "published") =>
      api
        .post("/api/publications", {
          campaignId,
          title: selected?.title,
          copy: editCopy,
          script: selected?.script,
          imageDescription: selected?.imageDescription,
          imageUrl: imageUrl ?? undefined,
          audience: selected?.audience,
          dailyBudget: Number(editBudget),
          whatsappNumber: editWhatsapp,
          cta: selected?.cta,
          platform,
          format,
          status,
        })
        .then((r) => r.data),
    onSuccess: async (data, status) => {
      if (status === "published" && data.id) {
        try {
          await api.post(`/api/publish/${data.id}`)
          toast.success("Publicacion creada y publicada")
        } catch {
          toast.success("Publicacion guardada, pero fallo al publicar")
        }
      } else {
        toast.success("Publicacion guardada como borrador")
      }
      queryClient.invalidateQueries({
        queryKey: ["campaign-publications", campaignId],
      })
      queryClient.invalidateQueries({ queryKey: ["campaign", campaignId] })
      navigate(data.id ? `/publications/${data.id}` : `/campaigns/${campaignId}`)
    },
    onError: () => {
      toast.error("Error al guardar la publicacion")
    },
  })

  const handleSelectProposal = (proposal: PublicationProposal) => {
    const sel: SelectedProposal = {
      ...proposal,
      copy: proposal.copy ?? "",
      dailyBudget: proposal.dailyBudget,
      whatsappNumber: campaign?.whatsappNumber ?? "",
    }
    setSelected(sel)
    setEditCopy(sel.copy)
    setEditBudget(String(sel.dailyBudget))
    setEditWhatsapp(sel.whatsappNumber)
    resetImage()
    setStep(3)
  }

  const stepLabels = ["Descripcion", "Propuestas", "Vista previa"]

  return (
    <div className="max-w-4xl mx-auto space-y-6">
      {/* Breadcrumb */}
      <nav className="flex items-center gap-1 text-sm text-muted-foreground">
        <Link to="/campaigns" className="hover:text-foreground">
          Campanas
        </Link>
        <ChevronRight className="h-4 w-4" />
        <Link
          to={`/campaigns/${campaignId}`}
          className="hover:text-foreground"
        >
          {campaign?.name ?? "..."}
        </Link>
        <ChevronRight className="h-4 w-4" />
        <span className="text-foreground">Nueva publicacion</span>
      </nav>

      <h1 className="text-2xl font-bold">
        Nueva publicacion en {campaign?.name ?? "..."}
      </h1>

      {/* Step indicator */}
      <div className="flex items-center gap-2">
        {stepLabels.map((label, i) => {
          const stepNum = (i + 1) as Step
          const isActive = step === stepNum
          const isDone = step > stepNum
          return (
            <div key={label} className="flex items-center gap-2">
              {i > 0 && (
                <div
                  className={`h-px w-8 ${isDone ? "bg-primary" : "bg-muted"}`}
                />
              )}
              <div
                className={`flex items-center gap-2 text-sm font-medium ${
                  isActive
                    ? "text-primary"
                    : isDone
                      ? "text-foreground"
                      : "text-muted-foreground"
                }`}
              >
                <span
                  className={`flex h-6 w-6 items-center justify-center rounded-full text-xs ${
                    isActive
                      ? "bg-primary text-primary-foreground"
                      : isDone
                        ? "bg-primary/20 text-primary"
                        : "bg-muted text-muted-foreground"
                  }`}
                >
                  {stepNum}
                </span>
                <span className="hidden sm:inline">{label}</span>
              </div>
            </div>
          )
        })}
      </div>

      {/* STEP 1: Input */}
      {step === 1 && (
        <Card>
          <CardHeader>
            <CardTitle>Describe tu anuncio</CardTitle>
            <CardDescription>
              Cuentanos que tipo de anuncio quieres crear y la IA generara 3
              propuestas.
            </CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="space-y-2">
              <label className="text-sm font-medium">Descripcion</label>
              <Textarea
                rows={5}
                placeholder="Quiero un anuncio que promocione mi tienda de ropa para jovenes..."
                value={prompt}
                onChange={(e) => setPrompt(e.target.value)}
              />
            </div>

            <div className="grid grid-cols-1 gap-4 sm:grid-cols-2">
              <div className="space-y-2">
                <label className="text-sm font-medium">Formato</label>
                <Select
                  value={format}
                  onValueChange={(val) => setFormat(val as typeof format)}
                >
                  <SelectTrigger>
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="1:1">Cuadrado (1:1)</SelectItem>
                    <SelectItem value="9:16">
                      Vertical / Stories (9:16)
                    </SelectItem>
                  </SelectContent>
                </Select>
              </div>

              <div className="space-y-2">
                <label className="text-sm font-medium">Plataforma</label>
                <Select
                  value={platform}
                  onValueChange={(val) =>
                    setPlatform(val as typeof platform)
                  }
                >
                  <SelectTrigger>
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="facebook">Facebook</SelectItem>
                    <SelectItem value="instagram">Instagram</SelectItem>
                    <SelectItem value="tiktok">TikTok</SelectItem>
                  </SelectContent>
                </Select>
              </div>
            </div>

            <Button
              onClick={() => generateMutation.mutate()}
              disabled={!prompt.trim() || generateMutation.isPending}
              className="w-full sm:w-auto"
            >
              {generateMutation.isPending ? (
                <Loader2 className="mr-1 h-4 w-4 animate-spin" />
              ) : (
                <Sparkles className="mr-1 h-4 w-4" />
              )}
              Generar 3 propuestas con IA
            </Button>

            {/* Loading state */}
            {generateMutation.isPending && (
              <div className="flex flex-col items-center gap-3 py-8">
                <Loader2 className="h-8 w-8 animate-spin text-primary" />
                <p className="text-sm text-muted-foreground">
                  Generando propuestas con IA...
                </p>
              </div>
            )}
          </CardContent>
        </Card>
      )}

      {/* STEP 2: Selection */}
      {step === 2 && (
        <div className="space-y-4">
          <div className="grid grid-cols-1 gap-4 md:grid-cols-3">
            {proposals.map((proposal, index) => (
              <ProposalCard
                key={proposal.id ?? index}
                proposal={{
                  name: proposal.title,
                  description: proposal.imageDescription,
                  objective: "",
                  audience: proposal.audience,
                  dailyBudget: proposal.dailyBudget,
                  copy: proposal.copy,
                  script: proposal.script,
                  imageDescription: proposal.imageDescription,
                  cta: proposal.cta,
                }}
                index={index}
                onSelect={() => handleSelectProposal(proposal)}
                onRegenerate={() => regenerateMutation.mutate(index)}
                isRegenerating={
                  regenerateMutation.isPending &&
                  regenerateMutation.variables === index
                }
              />
            ))}
          </div>

          <div className="flex justify-center">
            <Button
              variant="ghost"
              onClick={() => setStep(1)}
            >
              <ArrowLeft className="mr-1 h-4 w-4" />
              Ninguna, volver
            </Button>
          </div>
        </div>
      )}

      {/* STEP 3: Preview & Confirm */}
      {step === 3 && selected && (
        <div className="grid grid-cols-1 gap-6 lg:grid-cols-2">
          {/* Left: Ad preview */}
          <Card>
            <CardHeader>
              <CardTitle>Vista previa del anuncio</CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              {/* Image preview */}
              <div
                className={`relative rounded-lg border bg-muted overflow-hidden ${
                  format === "9:16" ? "aspect-[9/16]" : "aspect-square"
                }`}
              >
                {imageUrl ? (
                  <img
                    src={imageUrl}
                    alt="Imagen generada"
                    className="h-full w-full object-cover"
                  />
                ) : imageGenerating ? (
                  <div className="flex h-full w-full flex-col items-center justify-center gap-2">
                    <Loader2 className="h-8 w-8 animate-spin text-primary" />
                    <p className="text-sm text-muted-foreground">
                      Generando imagen...
                    </p>
                  </div>
                ) : (
                  <div className="flex h-full w-full flex-col items-center justify-center gap-2">
                    <ImageIcon className="h-12 w-12 text-muted-foreground" />
                    <p className="text-sm text-muted-foreground">
                      Sin imagen generada
                    </p>
                  </div>
                )}
              </div>

              <Button
                variant="outline"
                className="w-full"
                onClick={() => generateImage(selected.imageDescription)}
                disabled={imageGenerating}
              >
                {imageGenerating ? (
                  <Loader2 className="mr-1 h-4 w-4 animate-spin" />
                ) : imageUrl ? (
                  <RefreshCw className="mr-1 h-4 w-4" />
                ) : (
                  <ImageIcon className="mr-1 h-4 w-4" />
                )}
                {imageUrl ? "Regenerar imagen" : "Generar imagen"}
              </Button>

              {/* Ad text preview */}
              <div className="space-y-2 rounded-lg border p-4">
                <p className="font-semibold">{selected.title}</p>
                <p className="text-sm">{editCopy}</p>
                <p className="text-xs text-muted-foreground">
                  CTA: {selected.cta}
                </p>
              </div>
            </CardContent>
          </Card>

          {/* Right: Editable fields */}
          <Card>
            <CardHeader>
              <CardTitle>Detalles de la publicacion</CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="space-y-2">
                <label className="text-sm font-medium">Copy del anuncio</label>
                <Textarea
                  rows={4}
                  value={editCopy}
                  onChange={(e) => setEditCopy(e.target.value)}
                />
              </div>

              <div className="space-y-2">
                <label className="text-sm font-medium">
                  Presupuesto diario ($)
                </label>
                <Input
                  type="number"
                  min={1}
                  step="0.01"
                  value={editBudget}
                  onChange={(e) => setEditBudget(e.target.value)}
                />
              </div>

              <div className="space-y-2">
                <label className="text-sm font-medium">
                  Numero de WhatsApp
                </label>
                <Input
                  placeholder="+1234567890"
                  value={editWhatsapp}
                  onChange={(e) => setEditWhatsapp(e.target.value)}
                />
              </div>

              {/* Info summary */}
              <div className="rounded-lg bg-muted p-4 space-y-1 text-sm">
                <p>
                  <span className="font-medium">Plataforma:</span>{" "}
                  <span className="capitalize">{platform}</span>
                </p>
                <p>
                  <span className="font-medium">Formato:</span> {format}
                </p>
                <p>
                  <span className="font-medium">Audiencia:</span>{" "}
                  {selected.audience}
                </p>
                {selected.script && (
                  <p>
                    <span className="font-medium">Script:</span>{" "}
                    {selected.script}
                  </p>
                )}
              </div>

              {/* Action buttons */}
              <div className="flex flex-col gap-2 pt-4">
                <Button
                  onClick={() => saveMutation.mutate("published")}
                  disabled={saveMutation.isPending}
                >
                  {saveMutation.isPending ? (
                    <Loader2 className="mr-1 h-4 w-4 animate-spin" />
                  ) : (
                    <Send className="mr-1 h-4 w-4" />
                  )}
                  Guardar y publicar ahora
                </Button>
                <Button
                  variant="outline"
                  onClick={() => saveMutation.mutate("draft")}
                  disabled={saveMutation.isPending}
                >
                  {saveMutation.isPending ? (
                    <Loader2 className="mr-1 h-4 w-4 animate-spin" />
                  ) : (
                    <Save className="mr-1 h-4 w-4" />
                  )}
                  Guardar como borrador
                </Button>
                <Button
                  variant="ghost"
                  onClick={() => setStep(2)}
                >
                  <ArrowLeft className="mr-1 h-4 w-4" />
                  Volver a propuestas
                </Button>
              </div>
            </CardContent>
          </Card>
        </div>
      )}
    </div>
  )
}
