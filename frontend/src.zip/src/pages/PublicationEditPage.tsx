import { useRef } from "react"
import { useNavigate, useParams, Link } from "react-router-dom"
import { useQuery, useMutation } from "@tanstack/react-query"
import { queryClient } from "@/lib/queryClient"
import api from "@/lib/api"
import { toast } from "sonner"
import { useForm } from "react-hook-form"
import { zodResolver } from "@hookform/resolvers/zod"
import { z } from "zod"
import { useImageGeneration } from "@/hooks/useImageGeneration"
import type { Publication } from "@/types"
import { Loader2, ChevronRight, Sparkles, Upload } from "lucide-react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Textarea } from "@/components/ui/textarea"
import { Label } from "@/components/ui/label"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Skeleton } from "@/components/ui/skeleton"
import { AdPreview } from "@/components/AdPreview"
import { ImagePreview } from "@/components/ImagePreview"

const editSchema = z.object({
  title: z.string().min(1, "El título es requerido"),
  copy: z.string().min(1, "El copy es requerido"),
  script: z.string().optional(),
  dailyBudget: z.coerce.number().min(0, "El presupuesto debe ser positivo"),
  whatsappNumber: z.string().min(1, "El número de WhatsApp es requerido"),
})

type EditFormValues = z.infer<typeof editSchema>

export default function PublicationEditPage() {
  const { publicationId } = useParams<{ publicationId: string }>()
  const navigate = useNavigate()
  const fileInputRef = useRef<HTMLInputElement>(null)
  const { generate, imageUrl: generatedImageUrl, isGenerating } = useImageGeneration()

  const {
    data: publication,
    isLoading,
    isError,
  } = useQuery<Publication>({
    queryKey: ["publication", publicationId],
    queryFn: () => api.get(`/api/campaigns/${publicationId}`).then((r) => r.data),
    enabled: !!publicationId,
  })

  const {
    register,
    handleSubmit,
    watch,
    formState: { errors },
  } = useForm<EditFormValues>({
    resolver: zodResolver(editSchema),
    values: publication
      ? {
          title: publication.title,
          copy: publication.copy,
          script: publication.script ?? "",
          dailyBudget: publication.dailyBudget,
          whatsappNumber: publication.whatsappNumber,
        }
      : undefined,
  })

  const watchedValues = watch()

  const saveMutation = useMutation({
    mutationFn: (data: EditFormValues) =>
      api.patch(`/api/campaigns/${publicationId}`, data),
    onSuccess: () => {
      toast.success("Cambios guardados exitosamente")
      queryClient.invalidateQueries({ queryKey: ["publication", publicationId] })
      navigate(`/publications/${publicationId}`)
    },
    onError: () => toast.error("Error al guardar los cambios"),
  })

  const uploadMutation = useMutation({
    mutationFn: (file: File) => {
      const formData = new FormData()
      formData.append("image", file)
      return api.patch(`/api/campaigns/${publicationId}/image`, formData, {
        headers: { "Content-Type": "multipart/form-data" },
      })
    },
    onSuccess: () => {
      toast.success("Imagen actualizada")
      queryClient.invalidateQueries({ queryKey: ["publication", publicationId] })
    },
    onError: () => toast.error("Error al subir la imagen"),
  })

  const onSubmit = (data: EditFormValues) => {
    saveMutation.mutate(data)
  }

  const handleFileUpload = (file: File) => {
    uploadMutation.mutate(file)
  }

  const handleGenerateImage = () => {
    if (publication?.imageDescription) {
      generate(publication.imageDescription)
    } else {
      toast.error("No hay descripción de imagen disponible")
    }
  }

  if (isLoading) {
    return (
      <div className="space-y-6 p-6">
        <Skeleton className="h-8 w-64" />
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
          <Skeleton className="h-[500px]" />
          <Skeleton className="h-[500px]" />
        </div>
      </div>
    )
  }

  if (isError || !publication) {
    return (
      <div className="flex flex-col items-center justify-center p-12 gap-4">
        <p className="text-muted-foreground">No se encontró la publicación.</p>
        <Button variant="outline" onClick={() => navigate(-1)}>
          Volver
        </Button>
      </div>
    )
  }

  if (publication.status !== "draft") {
    return (
      <div className="flex flex-col items-center justify-center p-12 gap-4">
        <p className="text-lg font-medium">Solo puedes editar publicaciones en borrador</p>
        <p className="text-muted-foreground">
          Esta publicación tiene estado "{publication.status}" y no puede ser editada.
        </p>
        <Button variant="outline" asChild>
          <Link to={`/publications/${publicationId}`}>Volver a la publicación</Link>
        </Button>
      </div>
    )
  }

  const currentImageUrl = generatedImageUrl ?? publication.imageUrl

  return (
    <div className="space-y-8 p-6">
      {/* Breadcrumb */}
      <nav className="flex items-center gap-1 text-sm text-muted-foreground">
        <Link to="/campaigns" className="hover:text-foreground transition-colors">
          Campañas
        </Link>
        <ChevronRight className="h-4 w-4" />
        <Link
          to={`/publications/${publicationId}`}
          className="hover:text-foreground transition-colors"
        >
          {publication.title}
        </Link>
        <ChevronRight className="h-4 w-4" />
        <span className="text-foreground font-medium">Editar</span>
      </nav>

      <h1 className="text-2xl font-bold">Editar publicación</h1>

      <form onSubmit={handleSubmit(onSubmit)} className="space-y-8">
        {/* Two-column layout */}
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
          {/* Left: Form */}
          <div className="space-y-6">
            <div className="space-y-2">
              <Label htmlFor="title">Título</Label>
              <Input
                id="title"
                {...register("title")}
                className="bg-gray-800 border-gray-700"
              />
              {errors.title && (
                <p className="text-sm text-red-500">{errors.title.message}</p>
              )}
            </div>

            <div className="space-y-2">
              <Label htmlFor="copy">Copy</Label>
              <Textarea
                id="copy"
                {...register("copy")}
                rows={8}
                className="bg-gray-800 border-gray-700 resize-none"
              />
              {errors.copy && (
                <p className="text-sm text-red-500">{errors.copy.message}</p>
              )}
            </div>

            <div className="space-y-2">
              <Label htmlFor="script">Script (opcional)</Label>
              <Textarea
                id="script"
                {...register("script")}
                rows={4}
                className="bg-gray-800 border-gray-700 resize-none"
              />
            </div>

            <div className="space-y-2">
              <Label htmlFor="dailyBudget">Presupuesto diario ($)</Label>
              <Input
                id="dailyBudget"
                type="number"
                step="0.01"
                {...register("dailyBudget")}
                className="bg-gray-800 border-gray-700"
              />
              {errors.dailyBudget && (
                <p className="text-sm text-red-500">{errors.dailyBudget.message}</p>
              )}
            </div>

            <div className="space-y-2">
              <Label htmlFor="whatsappNumber">Número de WhatsApp</Label>
              <Input
                id="whatsappNumber"
                {...register("whatsappNumber")}
                placeholder="+52 1234567890"
                className="bg-gray-800 border-gray-700"
              />
              {errors.whatsappNumber && (
                <p className="text-sm text-red-500">{errors.whatsappNumber.message}</p>
              )}
            </div>
          </div>

          {/* Right: Live Preview */}
          <div className="space-y-4">
            <p className="text-sm font-medium text-muted-foreground">Vista previa en vivo</p>
            <AdPreview
              platform={publication.platform}
              copy={watchedValues.copy ?? publication.copy}
              imageUrl={currentImageUrl}
              cta={publication.cta}
            />
          </div>
        </div>

        {/* Image Section */}
        <Card>
          <CardHeader>
            <CardTitle className="text-base">Imagen</CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="max-w-sm">
              <ImagePreview
                imageUrl={currentImageUrl}
                isGenerating={isGenerating}
                onRegenerate={handleGenerateImage}
                onUpload={handleFileUpload}
              />
            </div>
            <div className="flex gap-3">
              <Button
                type="button"
                variant="outline"
                onClick={() => fileInputRef.current?.click()}
              >
                <Upload className="h-4 w-4 mr-2" />
                Subir imagen
              </Button>
              <Button
                type="button"
                variant="outline"
                onClick={handleGenerateImage}
                disabled={isGenerating}
              >
                {isGenerating ? (
                  <Loader2 className="h-4 w-4 mr-2 animate-spin" />
                ) : (
                  <Sparkles className="h-4 w-4 mr-2" />
                )}
                Generar con IA
              </Button>
              <input
                ref={fileInputRef}
                type="file"
                accept="image/*"
                className="hidden"
                onChange={(e) => {
                  const file = e.target.files?.[0]
                  if (file) handleFileUpload(file)
                }}
              />
            </div>
          </CardContent>
        </Card>

        {/* Actions */}
        <div className="flex gap-3">
          <Button type="submit" disabled={saveMutation.isPending}>
            {saveMutation.isPending && <Loader2 className="h-4 w-4 mr-2 animate-spin" />}
            Guardar cambios
          </Button>
          <Button type="button" variant="outline" onClick={() => navigate(-1)}>
            Cancelar
          </Button>
        </div>
      </form>
    </div>
  )
}
