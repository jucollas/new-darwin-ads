import { useNavigate, useParams, Link } from "react-router-dom"
import { useQuery, useMutation } from "@tanstack/react-query"
import { queryClient } from "@/lib/queryClient"
import api from "@/lib/api"
import { toast } from "sonner"
import { useUIStore } from "@/store/ui.store"
import type { Publication, CampaignAnalytics } from "@/types"
import {
  Send,
  Pencil,
  Trash,
  Pause,
  ExternalLink,
  Copy,
  Play,
  Eye,
  Users,
  MousePointerClick,
  Percent,
  DollarSign,
  BarChart3,
  Target,
  MessageCircle,
  ChevronRight,
  Loader2,
} from "lucide-react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Skeleton } from "@/components/ui/skeleton"
import { AdPreview } from "@/components/AdPreview"
import { StatusBadge } from "@/components/StatusBadge"
import { MetricCard } from "@/components/MetricCard"
import {
  LineChart,
  Line,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip as RechartsTooltip,
  ResponsiveContainer,
} from "recharts"

export default function PublicationDetailPage() {
  const { publicationId } = useParams<{ publicationId: string }>()
  const navigate = useNavigate()
  const openConfirmDialog = useUIStore((s) => s.openConfirmDialog)

  const {
    data: publication,
    isLoading,
    isError,
  } = useQuery<Publication>({
    queryKey: ["publication", publicationId],
    queryFn: () => api.get(`/api/campaigns/${publicationId}`).then((r) => r.data),
    enabled: !!publicationId,
  })

  const { data: analytics } = useQuery<CampaignAnalytics>({
    queryKey: ["publication-analytics", publicationId],
    queryFn: () => api.get(`/api/analytics/${publicationId}`).then((r) => r.data),
    enabled: !!publicationId && publication?.status === "published",
  })

  const publishMutation = useMutation({
    mutationFn: () => api.post(`/api/publish/${publicationId}`),
    onSuccess: () => {
      toast.success("Publicación publicada exitosamente")
      queryClient.invalidateQueries({ queryKey: ["publication", publicationId] })
    },
    onError: () => toast.error("Error al publicar"),
  })

  const pauseMutation = useMutation({
    mutationFn: () => api.patch(`/api/publish/pause/${publicationId}`),
    onSuccess: () => {
      toast.success("Publicación pausada")
      queryClient.invalidateQueries({ queryKey: ["publication", publicationId] })
    },
    onError: () => toast.error("Error al pausar"),
  })

  const resumeMutation = useMutation({
    mutationFn: () => api.patch(`/api/publish/resume/${publicationId}`),
    onSuccess: () => {
      toast.success("Publicación reactivada")
      queryClient.invalidateQueries({ queryKey: ["publication", publicationId] })
    },
    onError: () => toast.error("Error al reactivar"),
  })

  const deleteMutation = useMutation({
    mutationFn: () => api.delete(`/api/campaigns/${publicationId}`),
    onSuccess: () => {
      toast.success("Publicación eliminada")
      navigate(-1)
    },
    onError: () => toast.error("Error al eliminar"),
  })

  const handleDelete = () => {
    openConfirmDialog({
      title: "Eliminar publicación",
      message: "¿Estás seguro de que deseas eliminar esta publicación? Esta acción no se puede deshacer.",
      onConfirm: () => deleteMutation.mutate(),
    })
  }

  if (isLoading) {
    return (
      <div className="space-y-6 p-6">
        <Skeleton className="h-8 w-64" />
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
          <Skeleton className="h-96" />
          <Skeleton className="h-96" />
        </div>
      </div>
    )
  }

  if (isError || !publication) {
    return (
      <div className="flex flex-col items-center justify-center p-12 gap-4">
        <p className="text-muted-foreground">No se encontró la publicación.</p>
        <Button variant="outline" onClick={() => navigate(-1)}>
          Volver
        </Button>
      </div>
    )
  }

  const ctr =
    publication.impressions > 0
      ? ((publication.clicks / publication.impressions) * 100).toFixed(2)
      : "0.00"
  const cpm =
    publication.impressions > 0
      ? ((publication.spend / publication.impressions) * 1000).toFixed(2)
      : "0.00"
  const cpc =
    publication.clicks > 0
      ? (publication.spend / publication.clicks).toFixed(2)
      : "0.00"
  const costPerConversation =
    publication.whatsappConversations > 0
      ? (publication.spend / publication.whatsappConversations).toFixed(2)
      : "0.00"

  return (
    <div className="space-y-8 p-6">
      {/* Breadcrumb */}
      <nav className="flex items-center gap-1 text-sm text-muted-foreground">
        <Link to="/campaigns" className="hover:text-foreground transition-colors">
          Campañas
        </Link>
        <ChevronRight className="h-4 w-4" />
        <Link
          to={`/campaigns/${publication.campaignId}`}
          className="hover:text-foreground transition-colors"
        >
          Campaña
        </Link>
        <ChevronRight className="h-4 w-4" />
        <span className="text-foreground font-medium">{publication.title}</span>
      </nav>

      {/* Top Section */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
        {/* Left: Ad Preview */}
        <div>
          <AdPreview
            platform={publication.platform}
            copy={publication.copy}
            imageUrl={publication.imageUrl}
            cta={publication.cta}
          />
        </div>

        {/* Right: Status + Actions */}
        <div className="space-y-6">
          <div className="flex items-center gap-3">
            <h1 className="text-2xl font-bold">{publication.title}</h1>
            <StatusBadge status={publication.status} />
          </div>

          {publication.script && (
            <Card>
              <CardHeader className="pb-2">
                <CardTitle className="text-sm font-medium">Script</CardTitle>
              </CardHeader>
              <CardContent>
                <p className="text-sm text-muted-foreground whitespace-pre-line">
                  {publication.script}
                </p>
              </CardContent>
            </Card>
          )}

          <div className="flex flex-wrap gap-3">
            {publication.status === "draft" && (
              <>
                <Button
                  onClick={() => publishMutation.mutate()}
                  disabled={publishMutation.isPending}
                >
                  {publishMutation.isPending ? (
                    <Loader2 className="h-4 w-4 mr-2 animate-spin" />
                  ) : (
                    <Send className="h-4 w-4 mr-2" />
                  )}
                  Publicar ahora
                </Button>
                <Button
                  variant="outline"
                  onClick={() => navigate(`/publications/${publicationId}/edit`)}
                >
                  <Pencil className="h-4 w-4 mr-2" />
                  Editar
                </Button>
                <Button variant="destructive" onClick={handleDelete}>
                  <Trash className="h-4 w-4 mr-2" />
                  Eliminar
                </Button>
              </>
            )}

            {publication.status === "published" && (
              <>
                <Button
                  variant="outline"
                  onClick={() => pauseMutation.mutate()}
                  disabled={pauseMutation.isPending}
                >
                  {pauseMutation.isPending ? (
                    <Loader2 className="h-4 w-4 mr-2 animate-spin" />
                  ) : (
                    <Pause className="h-4 w-4 mr-2" />
                  )}
                  Pausar
                </Button>
                <Button variant="outline" asChild>
                  <a href="#" target="_blank" rel="noopener noreferrer">
                    <ExternalLink className="h-4 w-4 mr-2" />
                    Ver en plataforma
                  </a>
                </Button>
                <Button variant="outline">
                  <Copy className="h-4 w-4 mr-2" />
                  Duplicar
                </Button>
              </>
            )}

            {publication.status === "paused" && (
              <>
                <Button
                  onClick={() => resumeMutation.mutate()}
                  disabled={resumeMutation.isPending}
                >
                  {resumeMutation.isPending ? (
                    <Loader2 className="h-4 w-4 mr-2 animate-spin" />
                  ) : (
                    <Play className="h-4 w-4 mr-2" />
                  )}
                  Reactivar
                </Button>
                <Button variant="destructive" onClick={handleDelete}>
                  <Trash className="h-4 w-4 mr-2" />
                  Eliminar
                </Button>
              </>
            )}
          </div>
        </div>
      </div>

      {/* Metrics Section (only if published) */}
      {publication.status === "published" && (
        <div className="space-y-6">
          <h2 className="text-xl font-semibold">Métricas</h2>

          <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
            <MetricCard title="Impresiones" value={publication.impressions.toLocaleString()} icon={Eye} />
            <MetricCard title="Alcance" value={publication.reach.toLocaleString()} icon={Users} />
            <MetricCard title="Clicks" value={publication.clicks.toLocaleString()} icon={MousePointerClick} />
            <MetricCard title="CTR" value={`${ctr}%`} icon={Percent} />
            <MetricCard title="Gasto" value={`$${publication.spend.toFixed(2)}`} icon={DollarSign} />
            <MetricCard title="CPM" value={`$${cpm}`} icon={BarChart3} />
            <MetricCard title="CPC" value={`$${cpc}`} icon={Target} />
          </div>

          {/* WhatsApp highlighted card */}
          <Card className="border-green-500/30 bg-green-500/5">
            <CardContent className="flex items-center gap-6 p-6">
              <div className="flex items-center gap-3">
                <div className="rounded-full bg-green-500/10 p-3">
                  <MessageCircle className="h-6 w-6 text-green-500" />
                </div>
                <div>
                  <p className="text-sm text-muted-foreground">Conversaciones WhatsApp</p>
                  <p className="text-2xl font-bold">{publication.whatsappConversations}</p>
                </div>
              </div>
              <div className="border-l pl-6">
                <p className="text-sm text-muted-foreground">Costo por conversación</p>
                <p className="text-2xl font-bold">${costPerConversation}</p>
              </div>
            </CardContent>
          </Card>

          {/* Line Chart */}
          {analytics?.dailyMetrics && analytics.dailyMetrics.length > 0 && (
            <Card>
              <CardHeader>
                <CardTitle className="text-base">Rendimiento últimos 7 días</CardTitle>
              </CardHeader>
              <CardContent>
                <ResponsiveContainer width="100%" height={300}>
                  <LineChart data={analytics.dailyMetrics}>
                    <CartesianGrid strokeDasharray="3 3" stroke="hsl(0 0% 20%)" />
                    <XAxis
                      dataKey="date"
                      tick={{ fontSize: 12 }}
                      stroke="hsl(0 0% 40%)"
                    />
                    <YAxis tick={{ fontSize: 12 }} stroke="hsl(0 0% 40%)" />
                    <RechartsTooltip
                      contentStyle={{
                        backgroundColor: "hsl(0 0% 10%)",
                        border: "1px solid hsl(0 0% 20%)",
                        borderRadius: "8px",
                      }}
                    />
                    <Line
                      type="monotone"
                      dataKey="impressions"
                      name="Impresiones"
                      stroke="hsl(262, 83%, 58%)"
                      strokeWidth={2}
                      dot={false}
                    />
                    <Line
                      type="monotone"
                      dataKey="whatsappConversations"
                      name="WhatsApp"
                      stroke="#22c55e"
                      strokeWidth={2}
                      dot={false}
                    />
                  </LineChart>
                </ResponsiveContainer>
              </CardContent>
            </Card>
          )}
        </div>
      )}

      {/* Genetic History Section */}
      {publication.parentIds && publication.parentIds.length > 0 && (
        <Card>
          <CardHeader>
            <CardTitle className="text-base">Historia genética</CardTitle>
          </CardHeader>
          <CardContent>
            <p className="text-sm text-muted-foreground">
              Esta publicación es hija de{" "}
              {publication.parentIds.map((parentId, index) => (
                <span key={parentId}>
                  <Link
                    to={`/publications/${parentId}`}
                    className="text-primary hover:underline font-medium"
                  >
                    {parentId}
                  </Link>
                  {index < publication.parentIds!.length - 1 && " y "}
                </span>
              ))}
              {publication.generation != null && (
                <> — Generación #{publication.generation}</>
              )}
            </p>
          </CardContent>
        </Card>
      )}
    </div>
  )
}
