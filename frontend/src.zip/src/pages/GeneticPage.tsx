import { useState } from "react"
import { useQuery, useMutation } from "@tanstack/react-query"
import { queryClient } from "@/lib/queryClient"
import api from "@/lib/api"
import { toast } from "sonner"
import { useAuthStore } from "@/store/auth.store"
import { useForm } from "react-hook-form"
import { zodResolver } from "@hookform/resolvers/zod"
import { z } from "zod"
import type { GeneticConfig, GeneticDecision, GeneticTreeNode } from "@/types"
import {
  Play,
  Settings,
  GitBranch,
  History,
  Loader2,
  Star,
  TreePine,
} from "lucide-react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Badge } from "@/components/ui/badge"
import { Switch } from "@/components/ui/switch"
import { Skeleton } from "@/components/ui/skeleton"
import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from "@/components/ui/card"
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select"
import { Separator } from "@/components/ui/separator"

const configSchema = z.object({
  enabled: z.boolean(),
  fitnessThreshold: z.coerce.number().min(0),
  evaluationFrequencyHours: z.coerce.number(),
  maxBudgetPerPublication: z.coerce.number().min(0),
})

type ConfigFormValues = z.infer<typeof configSchema>

interface GeneticHistoryResponse {
  config: GeneticConfig
  decisions: GeneticDecision[]
  tree: GeneticTreeNode[]
}

const actionLabels: Record<string, { label: string; className: string }> = {
  paused: { label: "Pausó", className: "bg-amber-100 text-amber-800 hover:bg-amber-100/80" },
  generated_variant: { label: "Generó variante", className: "bg-blue-100 text-blue-800 hover:bg-blue-100/80" },
  duplicated: { label: "Duplicó", className: "bg-green-100 text-green-800 hover:bg-green-100/80" },
}

function TreeNode({ node, depth = 0 }: { node: GeneticTreeNode; depth?: number }) {
  const isMuted = node.status === "paused" || node.status === "archived"
  const isTopPerformer = node.fitnessScore >= 4.0

  return (
    <div className="space-y-2" style={{ marginLeft: depth > 0 ? 24 : 0 }}>
      <div
        className={`flex items-center gap-3 rounded-lg border p-3 transition-colors ${
          isMuted ? "opacity-50 border-muted" : ""
        } ${isTopPerformer ? "border-green-500 bg-green-500/5" : ""}`}
      >
        {isTopPerformer && <Star className="h-4 w-4 text-green-500 shrink-0" />}
        <div className="flex-1 min-w-0">
          <p className="text-sm font-medium truncate">{node.title}</p>
          <div className="flex items-center gap-2 mt-1">
            <Badge variant="secondary" className="text-xs">
              Gen #{node.generation}
            </Badge>
            <span className="text-xs text-muted-foreground">
              Fitness: {node.fitnessScore.toFixed(2)}
            </span>
            <Badge
              variant="outline"
              className={`text-xs ${
                node.status === "published"
                  ? "border-green-500 text-green-600"
                  : node.status === "paused"
                    ? "border-amber-500 text-amber-600"
                    : ""
              }`}
            >
              {node.status}
            </Badge>
          </div>
        </div>
      </div>
      {node.children?.length > 0 && (
        <div className="border-l-2 border-muted ml-4 pl-2 space-y-2">
          {node.children.map((child) => (
            <TreeNode key={child.id} node={child} depth={depth + 1} />
          ))}
        </div>
      )}
    </div>
  )
}

export default function GeneticPage() {
  const user = useAuthStore((s) => s.user)
  const userId = user?.id

  const { data, isLoading } = useQuery<GeneticHistoryResponse>({
    queryKey: ["genetic-history", userId],
    queryFn: () => api.get(`/api/genetic/history/${userId}`).then((r) => r.data),
    enabled: !!userId,
  })

  const {
    register,
    handleSubmit,
    watch,
    setValue,
    formState: { errors },
  } = useForm<ConfigFormValues>({
    resolver: zodResolver(configSchema),
    values: data?.config
      ? {
          enabled: data.config.enabled,
          fitnessThreshold: data.config.fitnessThreshold,
          evaluationFrequencyHours: data.config.evaluationFrequencyHours,
          maxBudgetPerPublication: data.config.maxBudgetPerPublication,
        }
      : {
          enabled: false,
          fitnessThreshold: 2.0,
          evaluationFrequencyHours: 24,
          maxBudgetPerPublication: 50,
        },
  })

  const watchEnabled = watch("enabled")
  const watchFrequency = watch("evaluationFrequencyHours")

  const configureMutation = useMutation({
    mutationFn: (values: ConfigFormValues) =>
      api.patch(`/api/genetic/configure/${userId}`, values),
    onSuccess: () => {
      toast.success("Configuración guardada")
      queryClient.invalidateQueries({ queryKey: ["genetic-history", userId] })
    },
    onError: () => toast.error("Error al guardar configuración"),
  })

  const evaluateMutation = useMutation({
    mutationFn: () => api.post(`/api/genetic/evaluate/${userId}`),
    onSuccess: () => {
      toast.success("Evaluación completada")
      queryClient.invalidateQueries({ queryKey: ["genetic-history", userId] })
    },
    onError: () => toast.error("Error al ejecutar evaluación"),
  })

  const onSubmitConfig = (values: ConfigFormValues) => {
    configureMutation.mutate(values)
  }

  const decisions = data?.decisions ?? []
  const tree = data?.tree ?? []

  if (isLoading) {
    return (
      <div className="space-y-6 p-6">
        <Skeleton className="h-8 w-64" />
        <Skeleton className="h-64" />
        <Skeleton className="h-64" />
      </div>
    )
  }

  return (
    <div className="space-y-8 p-6">
      {/* Section 1: Configuration */}
      <div className="space-y-2">
        <div className="flex items-center gap-3">
          <Settings className="h-6 w-6 text-primary" />
          <div>
            <h1 className="text-2xl font-bold">Algoritmo Genético</h1>
            <p className="text-muted-foreground">Configuración y monitoreo</p>
          </div>
        </div>
      </div>

      <Card>
        <CardHeader>
          <CardTitle className="text-base">Configuración</CardTitle>
        </CardHeader>
        <CardContent>
          <form onSubmit={handleSubmit(onSubmitConfig)} className="space-y-6">
            <div className="flex items-center justify-between">
              <div className="space-y-0.5">
                <Label>Algoritmo genético automático</Label>
                <p className="text-sm text-muted-foreground">
                  {watchEnabled ? "Activado" : "Desactivado"}
                </p>
              </div>
              <Switch
                checked={watchEnabled}
                onCheckedChange={(checked) => setValue("enabled", checked)}
              />
            </div>

            <Separator />

            <div className="space-y-2">
              <Label htmlFor="fitnessThreshold">Umbral de fitness mínimo</Label>
              <Input
                id="fitnessThreshold"
                type="number"
                step="0.1"
                {...register("fitnessThreshold")}
                className="bg-gray-800 border-gray-700 max-w-xs"
              />
              <p className="text-sm text-muted-foreground">
                Publicaciones con score menor a este valor serán pausadas automáticamente
              </p>
              {errors.fitnessThreshold && (
                <p className="text-sm text-red-500">{errors.fitnessThreshold.message}</p>
              )}
            </div>

            <div className="space-y-2">
              <Label>Frecuencia de evaluación</Label>
              <Select
                value={String(watchFrequency)}
                onValueChange={(val) => setValue("evaluationFrequencyHours", Number(val))}
              >
                <SelectTrigger className="max-w-xs bg-gray-800 border-gray-700">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="24">Cada 24 horas</SelectItem>
                  <SelectItem value="48">Cada 48 horas</SelectItem>
                  <SelectItem value="72">Cada 72 horas</SelectItem>
                </SelectContent>
              </Select>
            </div>

            <div className="space-y-2">
              <Label htmlFor="maxBudgetPerPublication">Presupuesto máximo por publicación</Label>
              <div className="relative max-w-xs">
                <span className="absolute left-3 top-1/2 -translate-y-1/2 text-muted-foreground">
                  $
                </span>
                <Input
                  id="maxBudgetPerPublication"
                  type="number"
                  step="0.01"
                  {...register("maxBudgetPerPublication")}
                  className="bg-gray-800 border-gray-700 pl-7"
                />
              </div>
              {errors.maxBudgetPerPublication && (
                <p className="text-sm text-red-500">{errors.maxBudgetPerPublication.message}</p>
              )}
            </div>

            <div className="flex gap-3">
              <Button type="submit" disabled={configureMutation.isPending}>
                {configureMutation.isPending && (
                  <Loader2 className="h-4 w-4 mr-2 animate-spin" />
                )}
                Guardar configuración
              </Button>
              <Button
                type="button"
                variant="outline"
                onClick={() => evaluateMutation.mutate()}
                disabled={evaluateMutation.isPending}
              >
                {evaluateMutation.isPending ? (
                  <Loader2 className="h-4 w-4 mr-2 animate-spin" />
                ) : (
                  <Play className="h-4 w-4 mr-2" />
                )}
                Evaluar ahora
              </Button>
            </div>
          </form>
        </CardContent>
      </Card>

      {/* Section 2: Evolution Tree */}
      <Card>
        <CardHeader>
          <div className="flex items-center gap-2">
            <GitBranch className="h-5 w-5 text-primary" />
            <CardTitle className="text-base">Árbol de evolución</CardTitle>
          </div>
        </CardHeader>
        <CardContent>
          {tree.length > 0 ? (
            <div className="space-y-4">
              {tree.map((root) => (
                <TreeNode key={root.id} node={root} />
              ))}
            </div>
          ) : (
            <div className="flex flex-col items-center justify-center py-12 text-center gap-3">
              <TreePine className="h-12 w-12 text-muted-foreground/50" />
              <p className="text-muted-foreground">
                Aún no hay datos del árbol de evolución.
              </p>
              <p className="text-sm text-muted-foreground">
                El árbol se generará cuando el algoritmo genético procese tus publicaciones.
              </p>
            </div>
          )}
        </CardContent>
      </Card>

      {/* Section 3: Decision History */}
      <Card>
        <CardHeader>
          <div className="flex items-center gap-2">
            <History className="h-5 w-5 text-primary" />
            <CardTitle className="text-base">Historial de decisiones</CardTitle>
          </div>
        </CardHeader>
        <CardContent>
          {decisions.length > 0 ? (
            <div className="overflow-x-auto">
              <table className="w-full text-sm">
                <thead>
                  <tr className="border-b text-left">
                    <th className="pb-3 font-medium text-muted-foreground">Fecha</th>
                    <th className="pb-3 font-medium text-muted-foreground">Acción</th>
                    <th className="pb-3 font-medium text-muted-foreground">Publicación</th>
                    <th className="pb-3 font-medium text-muted-foreground">Razón</th>
                    <th className="pb-3 font-medium text-muted-foreground text-right">Score</th>
                  </tr>
                </thead>
                <tbody className="divide-y">
                  {decisions.map((decision) => {
                    const actionStyle = actionLabels[decision.action] ?? {
                      label: decision.action,
                      className: "",
                    }
                    return (
                      <tr key={decision.id}>
                        <td className="py-3 whitespace-nowrap">
                          {new Date(decision.createdAt).toLocaleDateString("es-ES", {
                            day: "2-digit",
                            month: "short",
                            year: "numeric",
                          })}
                        </td>
                        <td className="py-3">
                          <Badge
                            variant="secondary"
                            className={actionStyle.className}
                          >
                            {actionStyle.label}
                          </Badge>
                        </td>
                        <td className="py-3 font-medium">{decision.publicationTitle}</td>
                        <td className="py-3 text-muted-foreground max-w-xs truncate">
                          {decision.reason}
                        </td>
                        <td className="py-3 text-right font-mono">
                          {decision.fitnessScore.toFixed(2)}
                        </td>
                      </tr>
                    )
                  })}
                </tbody>
              </table>
            </div>
          ) : (
            <div className="flex flex-col items-center justify-center py-12 text-center gap-3">
              <History className="h-12 w-12 text-muted-foreground/50" />
              <p className="text-muted-foreground">
                No hay decisiones registradas aún.
              </p>
              <p className="text-sm text-muted-foreground">
                Las decisiones aparecerán aquí cuando el algoritmo genético evalúe tus publicaciones.
              </p>
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  )
}
