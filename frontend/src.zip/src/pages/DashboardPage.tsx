import { useState } from "react"
import { useNavigate } from "react-router-dom"
import { useQuery } from "@tanstack/react-query"
import {
  Megaphone,
  Send,
  Pause,
  DollarSign,
  Plus,
  TrendingDown,
  Copy,
  Sparkles,
  Clock,
} from "lucide-react"
import api from "@/lib/api"
import { useAuthStore } from "@/store/auth.store"
import { Button } from "@/components/ui/button"
import {
  Card,
  CardContent,
  CardHeader,
  CardTitle,
  CardDescription,
} from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Skeleton } from "@/components/ui/skeleton"
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogDescription,
} from "@/components/ui/dialog"
import type {
  AnalyticsSummary,
  Campaign,
  Publication,
  GeneticDecision,
} from "@/types"

function MetricCard({
  title,
  value,
  icon: Icon,
  loading,
}: {
  title: string
  value: string | number
  icon: React.ElementType
  loading: boolean
}) {
  return (
    <Card>
      <CardHeader className="flex flex-row items-center justify-between pb-2">
        <CardTitle className="text-sm font-medium text-muted-foreground">
          {title}
        </CardTitle>
        <Icon className="h-4 w-4 text-muted-foreground" />
      </CardHeader>
      <CardContent>
        {loading ? (
          <Skeleton className="h-8 w-24" />
        ) : (
          <div className="text-2xl font-bold">{value}</div>
        )}
      </CardContent>
    </Card>
  )
}

function StatusBadge({ status }: { status: string }) {
  const variants: Record<string, { label: string; variant: "default" | "secondary" | "destructive" | "outline" }> = {
    published: { label: "Publicada", variant: "default" },
    active: { label: "Activa", variant: "default" },
    paused: { label: "Pausada", variant: "secondary" },
    draft: { label: "Borrador", variant: "outline" },
    archived: { label: "Archivada", variant: "destructive" },
  }
  const config = variants[status] ?? { label: status, variant: "outline" as const }
  return <Badge variant={config.variant}>{config.label}</Badge>
}

const geneticActionIcons: Record<string, React.ElementType> = {
  paused: TrendingDown,
  generated_variant: Sparkles,
  duplicated: Copy,
}

export default function DashboardPage() {
  const navigate = useNavigate()
  const { user } = useAuthStore()
  const [showCampaignPicker, setShowCampaignPicker] = useState(false)

  const summaryQuery = useQuery<AnalyticsSummary>({
    queryKey: ["analytics-summary"],
    queryFn: () => api.get("/api/analytics/summary").then((r) => r.data),
    retry: false,
  })

  const campaignsQuery = useQuery<Campaign[]>({
    queryKey: ["campaigns-recent"],
    queryFn: () =>
      api
        .get("/api/campaigns?limit=5&sort=updated_at")
        .then((r) => {
          const body = r.data
          return Array.isArray(body) ? body : body.data ?? []
        }),
    retry: false,
  })

  const recentPublications = useQuery<Publication[]>({
    queryKey: ["publications-recent"],
    queryFn: () =>
      api
        .get("/api/publications?limit=5&sort=updated_at")
        .then((r) => {
          const body = r.data
          return Array.isArray(body) ? body : body.data ?? []
        }),
    retry: false,
  })

  const geneticQuery = useQuery<GeneticDecision[]>({
    queryKey: ["genetic-history"],
    queryFn: () =>
      api
        .get(`/api/genetic/history/${user?.id}?limit=5`)
        .then((r) => r.data),
    enabled: !!user?.id,
    retry: false,
  })

  const summary = summaryQuery.data
  const sLoading = summaryQuery.isLoading

  return (
    <div className="space-y-8">
      {/* Header */}
      <div>
        <h1 className="text-3xl font-bold">Dashboard</h1>
        <p className="text-muted-foreground">
          Resumen general de tu sistema
        </p>
      </div>

      {/* Metric cards */}
      <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
        <MetricCard
          title="Campañas activas"
          value={summary?.activeCampaigns ?? 0}
          icon={Megaphone}
          loading={sLoading}
        />
        <MetricCard
          title="Publicaciones publicadas"
          value={summary?.publishedPublications ?? 0}
          icon={Send}
          loading={sLoading}
        />
        <MetricCard
          title="Publicaciones pausadas"
          value={summary?.pausedPublications ?? 0}
          icon={Pause}
          loading={sLoading}
        />
        <MetricCard
          title="Gasto del mes"
          value={`$${(summary?.totalSpend ?? 0).toFixed(2)}`}
          icon={DollarSign}
          loading={sLoading}
        />
      </div>

      {/* Recent publications */}
      <Card>
        <CardHeader>
          <CardTitle>Publicaciones recientes</CardTitle>
          <CardDescription>
            Últimas 5 publicaciones actualizadas
          </CardDescription>
        </CardHeader>
        <CardContent>
          {recentPublications.isLoading ? (
            <div className="space-y-3">
              {Array.from({ length: 5 }).map((_, i) => (
                <Skeleton key={i} className="h-12 w-full" />
              ))}
            </div>
          ) : !recentPublications.data?.length ? (
            <p className="text-sm text-muted-foreground py-4 text-center">
              No hay publicaciones aún
            </p>
          ) : (
            <div className="overflow-x-auto">
              <table className="w-full text-sm">
                <thead>
                  <tr className="border-b text-left text-muted-foreground">
                    <th className="pb-2 font-medium">Título</th>
                    <th className="pb-2 font-medium">Estado</th>
                    <th className="pb-2 font-medium text-right">Impresiones</th>
                    <th className="pb-2 font-medium text-right">Clicks</th>
                    <th className="pb-2 font-medium text-right">WhatsApp</th>
                  </tr>
                </thead>
                <tbody>
                  {recentPublications.data.map((pub) => (
                    <tr
                      key={pub.id}
                      className="border-b last:border-0 cursor-pointer hover:bg-muted/50 transition-colors"
                      onClick={() => navigate(`/publications/${pub.id}`)}
                    >
                      <td className="py-3 font-medium">{pub.title}</td>
                      <td className="py-3">
                        <StatusBadge status={pub.status} />
                      </td>
                      <td className="py-3 text-right">
                        {pub.impressions.toLocaleString()}
                      </td>
                      <td className="py-3 text-right">
                        {pub.clicks.toLocaleString()}
                      </td>
                      <td className="py-3 text-right">
                        {pub.whatsappConversations.toLocaleString()}
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          )}
        </CardContent>
      </Card>

      {/* Genetic algorithm activity */}
      <Card>
        <CardHeader>
          <CardTitle>Actividad del algoritmo genético</CardTitle>
          <CardDescription>Últimas 5 decisiones automáticas</CardDescription>
        </CardHeader>
        <CardContent>
          {geneticQuery.isLoading ? (
            <div className="space-y-3">
              {Array.from({ length: 5 }).map((_, i) => (
                <Skeleton key={i} className="h-10 w-full" />
              ))}
            </div>
          ) : !geneticQuery.data?.length ? (
            <p className="text-sm text-muted-foreground py-4 text-center">
              Sin actividad reciente
            </p>
          ) : (
            <div className="space-y-3">
              {geneticQuery.data.map((decision) => {
                const ActionIcon =
                  geneticActionIcons[decision.action] ?? Clock
                return (
                  <div
                    key={decision.id}
                    className="flex items-start gap-3 rounded-lg border p-3"
                  >
                    <div className="mt-0.5 rounded-full bg-muted p-2">
                      <ActionIcon className="h-4 w-4" />
                    </div>
                    <div className="flex-1 space-y-1">
                      <p className="text-sm">{decision.reason}</p>
                      <div className="flex items-center gap-2 text-xs text-muted-foreground">
                        <span>
                          Puntuación: {decision.fitnessScore.toFixed(2)}
                        </span>
                        <span>·</span>
                        <span>
                          {new Date(decision.createdAt).toLocaleDateString(
                            "es-ES",
                            {
                              day: "numeric",
                              month: "short",
                              hour: "2-digit",
                              minute: "2-digit",
                            }
                          )}
                        </span>
                      </div>
                    </div>
                  </div>
                )
              })}
            </div>
          )}
        </CardContent>
      </Card>

      {/* Floating action button */}
      <Button
        className="fixed bottom-6 right-6 h-14 gap-2 rounded-full px-6 shadow-lg"
        onClick={() => setShowCampaignPicker(true)}
      >
        <Plus className="h-5 w-5" />
        Nueva Publicación
      </Button>

      {/* Campaign picker dialog */}
      <Dialog open={showCampaignPicker} onOpenChange={setShowCampaignPicker}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Selecciona una campaña</DialogTitle>
            <DialogDescription>
              Elige la campaña para la nueva publicación
            </DialogDescription>
          </DialogHeader>
          <div className="space-y-2 max-h-64 overflow-y-auto">
            {campaignsQuery.isLoading ? (
              <div className="space-y-2">
                {Array.from({ length: 3 }).map((_, i) => (
                  <Skeleton key={i} className="h-10 w-full" />
                ))}
              </div>
            ) : !campaignsQuery.data?.length ? (
              <p className="text-sm text-muted-foreground py-4 text-center">
                No tienes campañas. Crea una primero.
              </p>
            ) : (
              campaignsQuery.data.map((campaign) => (
                <button
                  key={campaign.id}
                  className="w-full text-left rounded-lg border p-3 hover:bg-muted/50 transition-colors"
                  onClick={() => {
                    setShowCampaignPicker(false)
                    navigate(`/publications/new/${campaign.id}`)
                  }}
                >
                  <p className="font-medium">{campaign.name}</p>
                  <p className="text-xs text-muted-foreground">
                    {campaign.description}
                  </p>
                </button>
              ))
            )}
          </div>
        </DialogContent>
      </Dialog>
    </div>
  )
}
