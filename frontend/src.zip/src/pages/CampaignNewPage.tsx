import { useState } from "react"
import { useNavigate } from "react-router-dom"
import { useMutation } from "@tanstack/react-query"
import {
  Sparkles,
  Check,
  ArrowLeft,
  Loader2,
  Phone,
  RefreshCw,
  Dna,
} from "lucide-react"
import { toast } from "sonner"
import api from "@/lib/api"
import { queryClient } from "@/lib/queryClient"
import { useAuthStore } from "@/store/auth.store"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Textarea } from "@/components/ui/textarea"
import {
  Card,
  CardContent,
  CardHeader,
  CardTitle,
  CardDescription,
  CardFooter,
} from "@/components/ui/card"
import { Skeleton } from "@/components/ui/skeleton"
import type { CampaignProposal, ProposalPack } from "@/types"

type Step = 1 | 2 | 3

export default function CampaignNewPage() {
  const navigate = useNavigate()
  const user = useAuthStore((s) => s.user)

  const [step, setStep] = useState<Step>(1)
  const [prompt, setPrompt] = useState("")
  const [proposals, setProposals] = useState<CampaignProposal[]>([])
  const [selectedProposal, setSelectedProposal] =
    useState<CampaignProposal | null>(null)
  const [regeneratingIdx, setRegeneratingIdx] = useState<number | null>(null)

  // Editable fields for step 3
  const [editName, setEditName] = useState("")
  const [editDescription, setEditDescription] = useState("")
  const [editWhatsapp, setEditWhatsapp] = useState("")

  // Step 1 -> generate proposals
  const generateMutation = useMutation({
    mutationFn: (userPrompt: string) =>
      api
        .post("/api/campaigns/generate", {
          user_prompt: userPrompt,
          user_id: user?.id ?? "anonymous",
        })
        .then((r) => (r.data as ProposalPack).proposals),
    onSuccess: (data) => {
      setProposals(data)
      setStep(2)
    },
    onError: (err: any) => {
      toast.error(
        err?.response?.data?.detail || "Error al generar propuestas"
      )
    },
  })

  // Regenerate a single proposal
  const handleRegenerate = async (index: number) => {
    setRegeneratingIdx(index)
    try {
      const { data } = await api.post<ProposalPack>(
        `/api/campaigns/regenerate/${index}`,
        {
          user_prompt: prompt,
          user_id: user?.id ?? "anonymous",
          original_proposals: proposals,
        }
      )
      setProposals(data.proposals)
    } catch (err: any) {
      toast.error(
        err?.response?.data?.detail || "Error al regenerar propuesta"
      )
    } finally {
      setRegeneratingIdx(null)
    }
  }

  // Step 3 -> create campaign
  const createMutation = useMutation({
    mutationFn: () =>
      api
        .post("/api/campaigns", {
          name: editName,
          description: editDescription,
          objective: selectedProposal?.objective,
          audience: selectedProposal?.target_audience,
          dailyBudget: selectedProposal?.suggested_budget,
          whatsappNumber: editWhatsapp,
        })
        .then((r) => r.data),
    onSuccess: (data) => {
      queryClient.invalidateQueries({ queryKey: ["campaigns"] })
      toast.success("Campaña creada exitosamente")
      navigate(`/campaigns/${data.id}`)
    },
    onError: (err: any) => {
      toast.error(
        err?.response?.data?.detail || "Error al crear la campaña"
      )
    },
  })

  const selectProposal = (proposal: CampaignProposal) => {
    setSelectedProposal(proposal)
    setEditName(proposal.title)
    setEditDescription(proposal.copy)
    setEditWhatsapp("")
    setStep(3)
  }

  return (
    <div className="mx-auto max-w-3xl space-y-6">
      {/* Step indicators */}
      <div className="flex items-center gap-2 text-sm text-muted-foreground">
        <span className={step >= 1 ? "text-primary font-medium" : ""}>
          1. Describe
        </span>
        <span>/</span>
        <span className={step >= 2 ? "text-primary font-medium" : ""}>
          2. Elige
        </span>
        <span>/</span>
        <span className={step >= 3 ? "text-primary font-medium" : ""}>
          3. Confirma
        </span>
      </div>

      {/* STEP 1 */}
      {step === 1 && (
        <div className="space-y-4">
          <div>
            <h1 className="text-3xl font-bold">Crear nueva campaña</h1>
            <p className="text-muted-foreground mt-1">
              Describe en lenguaje natural la campaña que quieres y la IA
              generará propuestas para ti
            </p>
          </div>

          <Textarea
            placeholder="Describe tu campaña... ej: Quiero una campaña para promocionar mi restaurante de comida italiana en Miami, orientada a parejas jóvenes, con un presupuesto de $10 diarios"
            value={prompt}
            onChange={(e) => setPrompt(e.target.value)}
            rows={6}
            className="resize-none"
          />

          <Button
            onClick={() => generateMutation.mutate(prompt)}
            disabled={!prompt.trim() || generateMutation.isPending}
            className="w-full sm:w-auto"
          >
            {generateMutation.isPending ? (
              <Loader2 className="mr-2 h-4 w-4 animate-spin" />
            ) : (
              <Sparkles className="mr-2 h-4 w-4" />
            )}
            Generar propuestas con IA
          </Button>

          {/* AI loading state */}
          {generateMutation.isPending && (
            <Card className="border-dashed">
              <CardContent className="flex flex-col items-center justify-center py-12">
                <Dna className="h-10 w-10 text-primary animate-spin mb-4" />
                <p className="text-sm font-medium">
                  La IA está generando propuestas...
                </p>
                <p className="text-xs text-muted-foreground mt-1">
                  Esto puede tomar unos segundos
                </p>
              </CardContent>
            </Card>
          )}
        </div>
      )}

      {/* STEP 2 */}
      {step === 2 && (
        <div className="space-y-4">
          <div>
            <h1 className="text-3xl font-bold">Elige una propuesta</h1>
            <p className="text-muted-foreground mt-1">
              Selecciona la propuesta que más te guste o regenera las que no
              te convenzan
            </p>
          </div>

          <div className="grid gap-4 sm:grid-cols-3">
            {proposals.map((proposal, index) => {
              const isRegenerating = regeneratingIdx === index
              return (
                <Card
                  key={index}
                  className="relative flex flex-col"
                >
                  {isRegenerating && (
                    <div className="absolute inset-0 z-10 flex items-center justify-center rounded-lg bg-background/80">
                      <Loader2 className="h-6 w-6 animate-spin text-primary" />
                    </div>
                  )}
                  <CardHeader>
                    <CardTitle className="text-base">
                      {proposal.title}
                    </CardTitle>
                    <CardDescription className="line-clamp-3">
                      {proposal.copy}
                    </CardDescription>
                  </CardHeader>
                  <CardContent className="flex-1 space-y-2 text-sm">
                    <div>
                      <span className="font-medium">Objetivo: </span>
                      {proposal.objective}
                    </div>
                    <div>
                      <span className="font-medium">Audiencia: </span>
                      <span className="text-muted-foreground">
                        {proposal.target_audience}
                      </span>
                    </div>
                    <div>
                      <span className="font-medium">Presupuesto: </span>$
                      {proposal.suggested_budget}/día
                    </div>
                  </CardContent>
                  <CardFooter className="gap-2">
                    <Button
                      size="sm"
                      className="flex-1"
                      onClick={() => selectProposal(proposal)}
                    >
                      Elegir
                    </Button>
                    <Button
                      size="sm"
                      variant="outline"
                      onClick={() => handleRegenerate(index)}
                      disabled={isRegenerating}
                    >
                      <RefreshCw className="h-3.5 w-3.5" />
                    </Button>
                  </CardFooter>
                </Card>
              )
            })}
          </div>

          <button
            onClick={() => {
              setStep(1)
              setProposals([])
            }}
            className="text-sm text-muted-foreground hover:text-foreground transition-colors"
          >
            <ArrowLeft className="inline mr-1 h-3.5 w-3.5" />
            Ninguna me convence, volver
          </button>
        </div>
      )}

      {/* STEP 3 */}
      {step === 3 && selectedProposal && (
        <div className="space-y-6">
          <div>
            <h1 className="text-3xl font-bold">Confirmar y crear campaña</h1>
            <p className="text-muted-foreground mt-1">
              Revisa los datos y ajusta lo que necesites antes de crear la
              campaña
            </p>
          </div>

          {/* Summary */}
          <Card>
            <CardHeader>
              <CardTitle className="text-base">
                Resumen de la propuesta
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-2 text-sm">
              <div>
                <span className="font-medium">Objetivo: </span>
                {selectedProposal.objective}
              </div>
              <div>
                <span className="font-medium">Audiencia: </span>
                {selectedProposal.target_audience}
              </div>
              <div>
                <span className="font-medium">Presupuesto sugerido: </span>$
                {selectedProposal.suggested_budget}/día
              </div>
            </CardContent>
          </Card>

          {/* Editable fields */}
          <div className="space-y-4">
            <div className="space-y-2">
              <label className="text-sm font-medium">
                Nombre de la campaña
              </label>
              <Input
                value={editName}
                onChange={(e) => setEditName(e.target.value)}
                placeholder="Nombre de la campaña"
              />
            </div>

            <div className="space-y-2">
              <label className="text-sm font-medium">Descripción</label>
              <Textarea
                value={editDescription}
                onChange={(e) => setEditDescription(e.target.value)}
                placeholder="Descripción de la campaña"
                rows={4}
                className="resize-none"
              />
            </div>

            <div className="space-y-2">
              <label className="text-sm font-medium">
                Número de WhatsApp
              </label>
              <div className="relative">
                <Phone className="absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground" />
                <Input
                  value={editWhatsapp}
                  onChange={(e) => setEditWhatsapp(e.target.value)}
                  placeholder="+1 234 567 8900"
                  className="pl-9"
                />
              </div>
            </div>
          </div>

          {/* Actions */}
          <div className="flex gap-3">
            <Button
              variant="outline"
              onClick={() => setStep(2)}
            >
              <ArrowLeft className="mr-2 h-4 w-4" />
              Volver
            </Button>
            <Button
              onClick={() => createMutation.mutate()}
              disabled={
                createMutation.isPending || !editName.trim() || !editWhatsapp.trim()
              }
            >
              {createMutation.isPending ? (
                <Loader2 className="mr-2 h-4 w-4 animate-spin" />
              ) : (
                <Check className="mr-2 h-4 w-4" />
              )}
              Crear campaña
            </Button>
          </div>
        </div>
      )}
    </div>
  )
}
