import { useState } from "react"
import { useParams, useNavigate, Link } from "react-router-dom"
import { useQuery, useMutation } from "@tanstack/react-query"
import { queryClient } from "@/lib/queryClient"
import api from "@/lib/api"
import { toast } from "sonner"
import {
  DollarSign,
  Eye,
  MousePointerClick,
  MessageCircle,
  Pencil,
  Plus,
  Trash2,
  MoreHorizontal,
  ChevronRight,
  Image as ImageIcon,
  Loader2,
} from "lucide-react"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { Card, CardContent } from "@/components/ui/card"
import { Skeleton } from "@/components/ui/skeleton"
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog"
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu"
import { MetricCard } from "@/components/MetricCard"
import { StatusBadge } from "@/components/StatusBadge"
import type { Campaign, Publication, CampaignAnalytics } from "@/types"

type TabFilter = "all" | "draft" | "published" | "paused"

const platformColors: Record<string, string> = {
  facebook: "bg-blue-100 text-blue-800",
  instagram: "bg-pink-100 text-pink-800",
  tiktok: "bg-slate-100 text-slate-800",
}

export default function CampaignDetailPage() {
  const { campaignId } = useParams<{ campaignId: string }>()
  const navigate = useNavigate()
  const [activeTab, setActiveTab] = useState<TabFilter>("all")
  const [deleteDialogOpen, setDeleteDialogOpen] = useState(false)

  const { data: campaign, isLoading: campaignLoading } = useQuery<Campaign>({
    queryKey: ["campaign", campaignId],
    queryFn: () => api.get(`/api/campaigns/${campaignId}`).then((r) => r.data),
  })

  const { data: publications = [], isLoading: pubsLoading } = useQuery<
    Publication[]
  >({
    queryKey: ["campaign-publications", campaignId],
    queryFn: () =>
      api
        .get(`/api/campaigns/${campaignId}/publications`)
        .then((r) => r.data),
  })

  const { data: analytics } = useQuery<CampaignAnalytics>({
    queryKey: ["campaign-analytics", campaignId],
    queryFn: () =>
      api.get(`/api/analytics/${campaignId}/summary`).then((r) => r.data),
  })

  const deleteMutation = useMutation({
    mutationFn: () => api.delete(`/api/campaigns/${campaignId}`),
    onSuccess: () => {
      toast.success("Campana eliminada correctamente")
      queryClient.invalidateQueries({ queryKey: ["campaigns"] })
      navigate("/campaigns")
    },
    onError: () => {
      toast.error("Error al eliminar la campana")
    },
  })

  const pubStatusMutation = useMutation({
    mutationFn: ({
      pubId,
      status,
    }: {
      pubId: string
      status: string
    }) => api.patch(`/api/publications/${pubId}/status`, { status }),
    onSuccess: () => {
      queryClient.invalidateQueries({
        queryKey: ["campaign-publications", campaignId],
      })
      toast.success("Estado actualizado")
    },
    onError: () => {
      toast.error("Error al cambiar el estado")
    },
  })

  const pubDeleteMutation = useMutation({
    mutationFn: (pubId: string) => api.delete(`/api/publications/${pubId}`),
    onSuccess: () => {
      queryClient.invalidateQueries({
        queryKey: ["campaign-publications", campaignId],
      })
      queryClient.invalidateQueries({ queryKey: ["campaign", campaignId] })
      toast.success("Publicacion eliminada")
    },
    onError: () => {
      toast.error("Error al eliminar la publicacion")
    },
  })

  const filteredPublications = publications.filter((p) =>
    activeTab === "all" ? true : p.status === activeTab
  )

  const tabs: { label: string; value: TabFilter }[] = [
    { label: "Todas", value: "all" },
    { label: "Borradores", value: "draft" },
    { label: "Publicadas", value: "published" },
    { label: "Pausadas", value: "paused" },
  ]

  if (campaignLoading) {
    return (
      <div className="space-y-6">
        <Skeleton className="h-8 w-64" />
        <Skeleton className="h-4 w-96" />
        <div className="grid grid-cols-1 gap-4 sm:grid-cols-2 lg:grid-cols-4">
          {Array.from({ length: 4 }).map((_, i) => (
            <Skeleton key={i} className="h-28" />
          ))}
        </div>
        <Skeleton className="h-64" />
      </div>
    )
  }

  if (!campaign) {
    return (
      <div className="flex flex-col items-center justify-center py-20">
        <p className="text-muted-foreground">Campana no encontrada</p>
        <Button variant="link" asChild>
          <Link to="/campaigns">Volver a campanas</Link>
        </Button>
      </div>
    )
  }

  return (
    <div className="space-y-6">
      {/* Breadcrumb */}
      <nav className="flex items-center gap-1 text-sm text-muted-foreground">
        <Link to="/campaigns" className="hover:text-foreground">
          Campanas
        </Link>
        <ChevronRight className="h-4 w-4" />
        <span className="text-foreground">{campaign.name}</span>
      </nav>

      {/* Header */}
      <div className="flex flex-col gap-4 sm:flex-row sm:items-start sm:justify-between">
        <div className="space-y-1">
          <div className="flex items-center gap-3">
            <h1 className="text-2xl font-bold">{campaign.name}</h1>
            <StatusBadge
              status={
                campaign.status === "active" ? "published" : campaign.status
              }
            />
          </div>
          <p className="text-muted-foreground">{campaign.description}</p>
        </div>

        <div className="flex items-center gap-2">
          <Button variant="outline" size="sm" asChild>
            <Link to={`/campaigns/${campaignId}/edit`}>
              <Pencil className="mr-1 h-4 w-4" />
              Editar
            </Link>
          </Button>
          <Button size="sm" asChild>
            <Link to={`/publications/new/${campaignId}`}>
              <Plus className="mr-1 h-4 w-4" />
              Nueva publicacion
            </Link>
          </Button>
          <Button
            variant="destructive"
            size="sm"
            onClick={() => setDeleteDialogOpen(true)}
          >
            <Trash2 className="mr-1 h-4 w-4" />
            Eliminar
          </Button>
        </div>
      </div>

      {/* Metrics */}
      <div className="grid grid-cols-1 gap-4 sm:grid-cols-2 lg:grid-cols-4">
        <MetricCard
          title="Gasto total"
          value={`$${(analytics?.totalSpend ?? 0).toLocaleString()}`}
          icon={DollarSign}
        />
        <MetricCard
          title="Impresiones"
          value={(analytics?.totalImpressions ?? 0).toLocaleString()}
          icon={Eye}
        />
        <MetricCard
          title="Clicks"
          value={(analytics?.totalClicks ?? 0).toLocaleString()}
          icon={MousePointerClick}
        />
        <MetricCard
          title="Conversaciones WhatsApp"
          value={(
            analytics?.totalWhatsappConversations ?? 0
          ).toLocaleString()}
          icon={MessageCircle}
        />
      </div>

      {/* Publications section */}
      <div className="space-y-4">
        <div className="flex items-center justify-between">
          <h2 className="text-lg font-semibold">
            Publicaciones{" "}
            <span className="text-muted-foreground font-normal">
              ({publications.length})
            </span>
          </h2>
        </div>

        {/* Filter tabs */}
        <div className="flex gap-1 border-b">
          {tabs.map((tab) => (
            <button
              key={tab.value}
              onClick={() => setActiveTab(tab.value)}
              className={`px-4 py-2 text-sm font-medium transition-colors border-b-2 -mb-px ${
                activeTab === tab.value
                  ? "border-primary text-primary"
                  : "border-transparent text-muted-foreground hover:text-foreground"
              }`}
            >
              {tab.label}
            </button>
          ))}
        </div>

        {pubsLoading ? (
          <div className="space-y-2">
            {Array.from({ length: 3 }).map((_, i) => (
              <Skeleton key={i} className="h-16 w-full" />
            ))}
          </div>
        ) : filteredPublications.length === 0 ? (
          <Card>
            <CardContent className="flex flex-col items-center justify-center py-12">
              <ImageIcon className="h-12 w-12 text-muted-foreground mb-4" />
              <p className="text-muted-foreground mb-4">
                {activeTab === "all"
                  ? "Esta campana no tiene publicaciones aun"
                  : `No hay publicaciones con estado "${tabs.find((t) => t.value === activeTab)?.label}"`}
              </p>
              {activeTab === "all" && (
                <Button asChild>
                  <Link to={`/publications/new/${campaignId}`}>
                    <Plus className="mr-1 h-4 w-4" />
                    Crear primera publicacion
                  </Link>
                </Button>
              )}
            </CardContent>
          </Card>
        ) : (
          <>
            {/* Desktop table */}
            <div className="hidden md:block overflow-x-auto rounded-md border">
              <table className="w-full text-sm">
                <thead>
                  <tr className="border-b bg-muted/50">
                    <th className="px-4 py-3 text-left font-medium">
                      Thumbnail
                    </th>
                    <th className="px-4 py-3 text-left font-medium">Titulo</th>
                    <th className="px-4 py-3 text-left font-medium">Estado</th>
                    <th className="px-4 py-3 text-left font-medium">
                      Plataforma
                    </th>
                    <th className="px-4 py-3 text-left font-medium">
                      Presupuesto
                    </th>
                    <th className="px-4 py-3 text-right font-medium">
                      Impresiones
                    </th>
                    <th className="px-4 py-3 text-right font-medium">
                      Clicks
                    </th>
                    <th className="px-4 py-3 text-right font-medium">
                      WhatsApp
                    </th>
                    <th className="px-4 py-3 text-left font-medium">Fecha</th>
                    <th className="px-4 py-3 text-right font-medium">
                      Acciones
                    </th>
                  </tr>
                </thead>
                <tbody>
                  {filteredPublications.map((pub) => (
                    <tr
                      key={pub.id}
                      className="border-b last:border-0 hover:bg-muted/30"
                    >
                      <td className="px-4 py-3">
                        <div className="h-10 w-10 rounded bg-muted overflow-hidden flex-shrink-0">
                          {pub.imageUrl ? (
                            <img
                              src={pub.imageUrl}
                              alt=""
                              className="h-full w-full object-cover"
                            />
                          ) : (
                            <div className="flex h-full w-full items-center justify-center">
                              <ImageIcon className="h-4 w-4 text-muted-foreground" />
                            </div>
                          )}
                        </div>
                      </td>
                      <td className="px-4 py-3 font-medium max-w-[200px] truncate">
                        {pub.title}
                      </td>
                      <td className="px-4 py-3">
                        <StatusBadge status={pub.status} />
                      </td>
                      <td className="px-4 py-3">
                        <Badge className={platformColors[pub.platform]}>
                          {pub.platform}
                        </Badge>
                      </td>
                      <td className="px-4 py-3">${pub.dailyBudget}/dia</td>
                      <td className="px-4 py-3 text-right">
                        {pub.impressions.toLocaleString()}
                      </td>
                      <td className="px-4 py-3 text-right">
                        {pub.clicks.toLocaleString()}
                      </td>
                      <td className="px-4 py-3 text-right">
                        {pub.whatsappConversations.toLocaleString()}
                      </td>
                      <td className="px-4 py-3 text-muted-foreground">
                        {new Date(pub.createdAt).toLocaleDateString("es-ES", {
                          day: "numeric",
                          month: "short",
                        })}
                      </td>
                      <td className="px-4 py-3 text-right">
                        <DropdownMenu>
                          <DropdownMenuTrigger asChild>
                            <Button variant="ghost" size="sm">
                              <MoreHorizontal className="h-4 w-4" />
                            </Button>
                          </DropdownMenuTrigger>
                          <DropdownMenuContent align="end">
                            <DropdownMenuItem
                              onClick={() =>
                                navigate(`/publications/${pub.id}`)
                              }
                            >
                              Ver
                            </DropdownMenuItem>
                            <DropdownMenuItem
                              onClick={() =>
                                navigate(`/publications/${pub.id}/edit`)
                              }
                            >
                              Editar
                            </DropdownMenuItem>
                            <DropdownMenuItem
                              onClick={() =>
                                pubStatusMutation.mutate({
                                  pubId: pub.id,
                                  status:
                                    pub.status === "published"
                                      ? "paused"
                                      : "published",
                                })
                              }
                            >
                              {pub.status === "published"
                                ? "Pausar"
                                : "Publicar"}
                            </DropdownMenuItem>
                            <DropdownMenuSeparator />
                            <DropdownMenuItem
                              className="text-destructive"
                              onClick={() => pubDeleteMutation.mutate(pub.id)}
                            >
                              Eliminar
                            </DropdownMenuItem>
                          </DropdownMenuContent>
                        </DropdownMenu>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>

            {/* Mobile cards */}
            <div className="grid gap-3 md:hidden">
              {filteredPublications.map((pub) => (
                <Card
                  key={pub.id}
                  className="cursor-pointer"
                  onClick={() => navigate(`/publications/${pub.id}`)}
                >
                  <CardContent className="flex items-center gap-3 p-4">
                    <div className="h-14 w-14 rounded bg-muted overflow-hidden flex-shrink-0">
                      {pub.imageUrl ? (
                        <img
                          src={pub.imageUrl}
                          alt=""
                          className="h-full w-full object-cover"
                        />
                      ) : (
                        <div className="flex h-full w-full items-center justify-center">
                          <ImageIcon className="h-5 w-5 text-muted-foreground" />
                        </div>
                      )}
                    </div>
                    <div className="flex-1 min-w-0">
                      <p className="font-medium truncate">{pub.title}</p>
                      <div className="flex items-center gap-2 mt-1">
                        <StatusBadge status={pub.status} />
                        <Badge className={platformColors[pub.platform]}>
                          {pub.platform}
                        </Badge>
                      </div>
                      <div className="flex gap-3 mt-1 text-xs text-muted-foreground">
                        <span>{pub.impressions.toLocaleString()} imp</span>
                        <span>{pub.clicks.toLocaleString()} clicks</span>
                        <span>{pub.whatsappConversations.toLocaleString()} WA</span>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>
          </>
        )}
      </div>

      {/* Delete confirmation dialog */}
      <Dialog open={deleteDialogOpen} onOpenChange={setDeleteDialogOpen}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Eliminar campana</DialogTitle>
            <DialogDescription>
              Esta accion no se puede deshacer. Se eliminaran todas las
              publicaciones asociadas a esta campana.
            </DialogDescription>
          </DialogHeader>
          <DialogFooter>
            <Button
              variant="outline"
              onClick={() => setDeleteDialogOpen(false)}
            >
              Cancelar
            </Button>
            <Button
              variant="destructive"
              onClick={() => {
                deleteMutation.mutate()
                setDeleteDialogOpen(false)
              }}
              disabled={deleteMutation.isPending}
            >
              {deleteMutation.isPending && (
                <Loader2 className="mr-1 h-4 w-4 animate-spin" />
              )}
              Eliminar
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  )
}
