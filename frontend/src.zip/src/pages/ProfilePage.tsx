import { useState } from "react"
import { useNavigate } from "react-router-dom"
import { useQuery, useMutation } from "@tanstack/react-query"
import { queryClient } from "@/lib/queryClient"
import api from "@/lib/api"
import { toast } from "sonner"
import { useAuthStore } from "@/store/auth.store"
import { useForm } from "react-hook-form"
import { zodResolver } from "@hookform/resolvers/zod"
import { z } from "zod"
import {
  User,
  Link2,
  Bell,
  LogOut,
  Loader2,
  CheckCircle,
  XCircle,
  Facebook,
  Camera,
} from "lucide-react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Switch } from "@/components/ui/switch"
import { Skeleton } from "@/components/ui/skeleton"
import { Separator } from "@/components/ui/separator"
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar"
import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from "@/components/ui/card"

const profileSchema = z.object({
  name: z.string().min(1, "El nombre es requerido"),
  whatsapp: z.string().optional(),
})

type ProfileFormValues = z.infer<typeof profileSchema>

interface NotificationPreferences {
  campaignPublished: boolean
  algorithmDecision: boolean
  imageGenerated: boolean
  weeklyMetrics: boolean
}

interface MetaConnection {
  connected: boolean
  adAccountName?: string
  facebookPageName?: string
}

export default function ProfilePage() {
  const navigate = useNavigate()
  const { user, logout, loadUser } = useAuthStore()
  const userId = user?.id

  const {
    register,
    handleSubmit,
    formState: { errors },
  } = useForm<ProfileFormValues>({
    resolver: zodResolver(profileSchema),
    values: user
      ? {
          name: user.name,
          whatsapp: user.whatsapp ?? "",
        }
      : undefined,
  })

  // Notification preferences
  const { data: notifPrefs, isLoading: notifLoading } = useQuery<NotificationPreferences>({
    queryKey: ["notification-preferences", userId],
    queryFn: () =>
      api.get(`/api/notifications/preferences/${userId}`).then((r) => r.data),
    enabled: !!userId,
  })

  const [localPrefs, setLocalPrefs] = useState<NotificationPreferences | null>(null)
  const prefs = localPrefs ?? notifPrefs

  // Meta connection status (derived from user or separate endpoint)
  const { data: metaConnection } = useQuery<MetaConnection>({
    queryKey: ["meta-connection", userId],
    queryFn: () => api.get(`/api/auth/meta-status`).then((r) => r.data),
    enabled: !!userId,
  })

  const profileMutation = useMutation({
    mutationFn: (data: ProfileFormValues) =>
      api.patch(`/api/auth/profile`, data),
    onSuccess: () => {
      toast.success("Perfil actualizado")
      loadUser()
    },
    onError: () => toast.error("Error al actualizar perfil"),
  })

  const notifMutation = useMutation({
    mutationFn: (prefs: NotificationPreferences) =>
      api.patch(`/api/notifications/preferences/${userId}`, prefs),
    onSuccess: () => {
      toast.success("Preferencias de notificación guardadas")
      queryClient.invalidateQueries({
        queryKey: ["notification-preferences", userId],
      })
    },
    onError: () => toast.error("Error al guardar preferencias"),
  })

  const handleProfileSubmit = (data: ProfileFormValues) => {
    profileMutation.mutate(data)
  }

  const handleTogglePref = (key: keyof NotificationPreferences) => {
    const current = prefs ?? {
      campaignPublished: true,
      algorithmDecision: true,
      imageGenerated: true,
      weeklyMetrics: true,
    }
    const updated = { ...current, [key]: !current[key] }
    setLocalPrefs(updated)
  }

  const handleSaveNotifPrefs = () => {
    if (prefs) {
      notifMutation.mutate(prefs)
    }
  }

  const handleLogout = () => {
    logout()
    navigate("/login")
  }

  const handleConnectMeta = () => {
    // Redirect to Meta OAuth flow
    window.location.href = `${import.meta.env.VITE_API_GATEWAY || ""}/api/auth/meta/connect`
  }

  const handleDisconnectMeta = async () => {
    try {
      await api.post("/api/auth/meta/disconnect")
      toast.success("Meta desconectado")
      queryClient.invalidateQueries({ queryKey: ["meta-connection", userId] })
    } catch {
      toast.error("Error al desconectar Meta")
    }
  }

  return (
    <div className="max-w-2xl mx-auto space-y-8 p-6">
      {/* Section 1: Personal Data */}
      <Card>
        <CardHeader>
          <div className="flex items-center gap-2">
            <User className="h-5 w-5 text-primary" />
            <CardTitle>Mi Perfil</CardTitle>
          </div>
        </CardHeader>
        <CardContent>
          <form
            onSubmit={handleSubmit(handleProfileSubmit)}
            className="space-y-6"
          >
            {/* Avatar */}
            <div className="flex items-center gap-4">
              <div className="relative group">
                <Avatar className="h-20 w-20">
                  <AvatarImage src={user?.avatarUrl} alt={user?.name} />
                  <AvatarFallback className="text-lg">
                    {user?.name?.charAt(0).toUpperCase() ?? "U"}
                  </AvatarFallback>
                </Avatar>
                <div className="absolute inset-0 flex items-center justify-center rounded-full bg-black/50 opacity-0 group-hover:opacity-100 transition-opacity cursor-pointer">
                  <Camera className="h-5 w-5 text-white" />
                </div>
              </div>
              <div>
                <p className="font-medium">{user?.name}</p>
                <p className="text-sm text-muted-foreground">{user?.email}</p>
              </div>
            </div>

            <div className="space-y-2">
              <Label htmlFor="name">Nombre</Label>
              <Input
                id="name"
                {...register("name")}
                className="bg-gray-800 border-gray-700"
              />
              {errors.name && (
                <p className="text-sm text-red-500">{errors.name.message}</p>
              )}
            </div>

            <div className="space-y-2">
              <Label htmlFor="email">Email</Label>
              <Input
                id="email"
                value={user?.email ?? ""}
                readOnly
                disabled
                className="bg-gray-800 border-gray-700 opacity-60"
              />
            </div>

            <div className="space-y-2">
              <Label htmlFor="whatsapp">Número de WhatsApp</Label>
              <Input
                id="whatsapp"
                {...register("whatsapp")}
                placeholder="+52 1234567890"
                className="bg-gray-800 border-gray-700"
              />
            </div>

            <Button type="submit" disabled={profileMutation.isPending}>
              {profileMutation.isPending && (
                <Loader2 className="h-4 w-4 mr-2 animate-spin" />
              )}
              Guardar cambios
            </Button>
          </form>
        </CardContent>
      </Card>

      {/* Section 2: Meta Connection */}
      <Card>
        <CardHeader>
          <div className="flex items-center gap-2">
            <Link2 className="h-5 w-5 text-primary" />
            <CardTitle>Conexiones</CardTitle>
          </div>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-3">
              <div className="rounded-lg bg-blue-600 p-2">
                <Facebook className="h-5 w-5 text-white" />
              </div>
              <div>
                <p className="font-medium">Meta / Facebook</p>
                {metaConnection?.connected ? (
                  <div className="flex items-center gap-1 text-sm text-green-500">
                    <CheckCircle className="h-3 w-3" />
                    Conectado
                  </div>
                ) : (
                  <div className="flex items-center gap-1 text-sm text-red-500">
                    <XCircle className="h-3 w-3" />
                    No conectado
                  </div>
                )}
              </div>
            </div>

            {metaConnection?.connected ? (
              <Button variant="outline" size="sm" onClick={handleDisconnectMeta}>
                Desconectar
              </Button>
            ) : (
              <Button size="sm" onClick={handleConnectMeta}>
                <Facebook className="h-4 w-4 mr-2" />
                Conectar con Meta
              </Button>
            )}
          </div>

          {metaConnection?.connected && (
            <div className="rounded-lg bg-muted/50 p-4 space-y-2 text-sm">
              {metaConnection.adAccountName && (
                <div className="flex justify-between">
                  <span className="text-muted-foreground">Cuenta de anuncios</span>
                  <span className="font-medium">{metaConnection.adAccountName}</span>
                </div>
              )}
              {metaConnection.facebookPageName && (
                <div className="flex justify-between">
                  <span className="text-muted-foreground">Página de Facebook</span>
                  <span className="font-medium">{metaConnection.facebookPageName}</span>
                </div>
              )}
            </div>
          )}
        </CardContent>
      </Card>

      {/* Section 3: Notification Preferences */}
      <Card>
        <CardHeader>
          <div className="flex items-center gap-2">
            <Bell className="h-5 w-5 text-primary" />
            <CardTitle>Notificaciones</CardTitle>
          </div>
        </CardHeader>
        <CardContent className="space-y-4">
          {notifLoading ? (
            <div className="space-y-4">
              <Skeleton className="h-10 w-full" />
              <Skeleton className="h-10 w-full" />
              <Skeleton className="h-10 w-full" />
              <Skeleton className="h-10 w-full" />
            </div>
          ) : (
            <>
              <div className="space-y-4">
                {([
                  { key: "campaignPublished" as const, label: "Campaña publicada" },
                  { key: "algorithmDecision" as const, label: "El algoritmo tomó una decisión" },
                  { key: "imageGenerated" as const, label: "Imagen generada" },
                  { key: "weeklyMetrics" as const, label: "Métricas semanales" },
                ]).map(({ key, label }) => (
                  <div key={key} className="flex items-center justify-between">
                    <Label className="cursor-pointer">{label}</Label>
                    <Switch
                      checked={prefs?.[key] ?? true}
                      onCheckedChange={() => handleTogglePref(key)}
                    />
                  </div>
                ))}
              </div>

              <Button
                onClick={handleSaveNotifPrefs}
                disabled={notifMutation.isPending}
                className="mt-4"
              >
                {notifMutation.isPending && (
                  <Loader2 className="h-4 w-4 mr-2 animate-spin" />
                )}
                Guardar preferencias
              </Button>
            </>
          )}
        </CardContent>
      </Card>

      {/* Section 4: Logout */}
      <Separator />

      <div className="pb-8">
        <Button variant="destructive" onClick={handleLogout}>
          <LogOut className="h-4 w-4 mr-2" />
          Cerrar sesión
        </Button>
      </div>
    </div>
  )
}
