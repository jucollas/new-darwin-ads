export interface User {
  id: string
  email: string
  name: string
  whatsapp?: string
  avatarUrl?: string
}

export interface Campaign {
  id: string
  userId: string
  name: string
  description: string
  objective: 'traffic' | 'conversion' | 'reach'
  audience: string
  dailyBudget: number
  whatsappNumber: string
  status: 'active' | 'paused' | 'draft'
  publicationsCount: number
  createdAt: string
  updatedAt: string
}

export interface CampaignProposal {
  title: string
  script: string
  copy: string
  image_description: string
  target_audience: string
  objective: string
  suggested_budget: number
  whatsapp_cta: string
}

export interface ProposalPack {
  type: 'proposal_pack'
  version: '1.0'
  proposals: CampaignProposal[]
  warnings: string[]
}

export interface Publication {
  id: string
  campaignId: string
  title: string
  copy: string
  script?: string
  imageDescription: string
  imageUrl?: string
  audience: string
  dailyBudget: number
  whatsappNumber: string
  cta: string
  platform: 'facebook' | 'instagram' | 'tiktok'
  format: '1:1' | '9:16'
  status: 'draft' | 'published' | 'paused' | 'archived'
  impressions: number
  clicks: number
  reach: number
  spend: number
  whatsappConversations: number
  publishedAt?: string
  createdAt: string
  updatedAt: string
  parentIds?: string[]
  generation?: number
  fitnessScore?: number
}

export interface PublicationProposal {
  id: string
  title: string
  copy: string
  script?: string
  imageDescription: string
  audience: string
  dailyBudget: number
  cta: string
}

export interface AnalyticsSummary {
  totalCampaigns: number
  activeCampaigns: number
  totalPublications: number
  publishedPublications: number
  pausedPublications: number
  totalSpend: number
  totalImpressions: number
  totalClicks: number
  totalWhatsappConversations: number
}

export interface CampaignAnalytics {
  campaignId: string
  totalSpend: number
  totalImpressions: number
  totalClicks: number
  totalWhatsappConversations: number
  dailyMetrics: DailyMetric[]
}

export interface DailyMetric {
  date: string
  impressions: number
  clicks: number
  whatsappConversations: number
  spend: number
}

export interface GeneticDecision {
  id: string
  action: 'paused' | 'generated_variant' | 'duplicated'
  publicationId: string
  publicationTitle: string
  campaignName: string
  reason: string
  fitnessScore: number
  createdAt: string
}

export interface GeneticConfig {
  enabled: boolean
  fitnessThreshold: number
  evaluationFrequencyHours: number
  maxBudgetPerPublication: number
}

export interface GeneticTreeNode {
  id: string
  title: string
  generation: number
  fitnessScore: number
  status: string
  children: GeneticTreeNode[]
}

export interface Notification {
  id: string
  type: string
  message: string
  read: boolean
  createdAt: string
}

export interface ImageJob {
  jobId: string
  status: 'pending' | 'processing' | 'completed' | 'failed'
  imageUrl?: string
}
