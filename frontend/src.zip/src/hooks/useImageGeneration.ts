import { useState, useRef, useCallback } from "react"
import api from "../lib/api"

export function useImageGeneration() {
  const [imageUrl, setImageUrl] = useState<string | null>(null)
  const [isGenerating, setIsGenerating] = useState(false)
  const intervalRef = useRef<ReturnType<typeof setInterval> | null>(null)

  const stopPolling = () => {
    if (intervalRef.current) {
      clearInterval(intervalRef.current)
      intervalRef.current = null
    }
  }

  const generate = useCallback(async (description: string) => {
    stopPolling()
    setImageUrl(null)
    setIsGenerating(true)

    try {
      const { data } = await api.post("/api/images/generate", { description })
      const jobId = data.jobId

      intervalRef.current = setInterval(async () => {
        try {
          const { data: status } = await api.get(
            `/api/images/status/${jobId}`,
          )

          if (status.status === "completed") {
            setImageUrl(status.imageUrl ?? null)
            setIsGenerating(false)
            stopPolling()
          } else if (status.status === "failed") {
            setIsGenerating(false)
            stopPolling()
          }
        } catch {
          setIsGenerating(false)
          stopPolling()
        }
      }, 3000)
    } catch {
      setIsGenerating(false)
    }
  }, [])

  const reset = useCallback(() => {
    stopPolling()
    setImageUrl(null)
    setIsGenerating(false)
  }, [])

  return { generate, imageUrl, isGenerating, reset }
}
