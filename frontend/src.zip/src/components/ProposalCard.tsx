import { RefreshCw, Target, Users, DollarSign } from "lucide-react"
import { Button } from "@/components/ui/button"
import {
  Card,
  CardContent,
  CardDescription,
  CardFooter,
  CardHeader,
  CardTitle,
} from "@/components/ui/card"

interface Proposal {
  name: string
  description: string
  objective: string
  audience: string
  dailyBudget: number
  copy?: string
  script?: string
  imageDescription?: string
  cta?: string
}

interface ProposalCardProps {
  proposal: Proposal
  onSelect: () => void
  onRegenerate: () => void
  isRegenerating?: boolean
  index: number
}

export function ProposalCard({
  proposal,
  onSelect,
  onRegenerate,
  isRegenerating = false,
  index,
}: ProposalCardProps) {
  return (
    <Card className="flex flex-col">
      <CardHeader>
        <CardDescription>Propuesta #{index + 1}</CardDescription>
        <CardTitle className="text-lg">{proposal.name}</CardTitle>
      </CardHeader>
      <CardContent className="flex-1 space-y-3">
        <p className="text-sm text-muted-foreground">{proposal.description}</p>

        <div className="space-y-2 text-sm">
          <div className="flex items-center gap-2">
            <Target className="h-4 w-4 text-muted-foreground" />
            <span className="font-medium">Objetivo:</span>
            <span className="capitalize">{proposal.objective}</span>
          </div>
          <div className="flex items-center gap-2">
            <Users className="h-4 w-4 text-muted-foreground" />
            <span className="font-medium">Audiencia:</span>
            <span>{proposal.audience}</span>
          </div>
          <div className="flex items-center gap-2">
            <DollarSign className="h-4 w-4 text-muted-foreground" />
            <span className="font-medium">Presupuesto diario:</span>
            <span>${proposal.dailyBudget}</span>
          </div>
        </div>

        {proposal.copy && (
          <div className="rounded-md bg-muted p-3">
            <p className="text-xs font-medium mb-1">Copy</p>
            <p className="text-sm">{proposal.copy}</p>
          </div>
        )}

        {proposal.script && (
          <div className="rounded-md bg-muted p-3">
            <p className="text-xs font-medium mb-1">Script</p>
            <p className="text-sm">{proposal.script}</p>
          </div>
        )}

        {proposal.imageDescription && (
          <div className="rounded-md bg-muted p-3">
            <p className="text-xs font-medium mb-1">Descripcion de imagen</p>
            <p className="text-sm">{proposal.imageDescription}</p>
          </div>
        )}

        {proposal.cta && (
          <div className="text-sm">
            <span className="font-medium">CTA:</span> {proposal.cta}
          </div>
        )}
      </CardContent>
      <CardFooter className="gap-2">
        <Button onClick={onSelect} className="flex-1">
          Elegir esta
        </Button>
        <Button
          variant="ghost"
          onClick={onRegenerate}
          disabled={isRegenerating}
        >
          <RefreshCw
            className={`h-4 w-4 mr-1 ${isRegenerating ? "animate-spin" : ""}`}
          />
          Regenerar
        </Button>
      </CardFooter>
    </Card>
  )
}
