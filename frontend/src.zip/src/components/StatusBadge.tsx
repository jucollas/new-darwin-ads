import { cn } from "@/lib/utils"
import { Badge } from "@/components/ui/badge"

type Status = "draft" | "published" | "paused" | "archived"

interface StatusBadgeProps {
  status: Status
}

const statusStyles: Record<Status, string> = {
  draft: "",
  published: "border-transparent bg-green-100 text-green-800 hover:bg-green-100/80",
  paused: "border-transparent bg-amber-100 text-amber-800 hover:bg-amber-100/80",
  archived: "border-transparent bg-red-100 text-red-800 hover:bg-red-100/80",
}

export function StatusBadge({ status }: StatusBadgeProps) {
  const isDraft = status === "draft"

  return (
    <Badge
      variant={isDraft ? "secondary" : undefined}
      className={cn(!isDraft && statusStyles[status])}
    >
      {status.charAt(0).toUpperCase() + status.slice(1)}
    </Badge>
  )
}
