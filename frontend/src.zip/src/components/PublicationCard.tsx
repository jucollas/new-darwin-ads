import { Image as ImageIcon, Eye, MousePointer, MessageCircle, DollarSign } from "lucide-react"
import { Badge } from "@/components/ui/badge"
import {
  Card,
  CardContent,
  CardHeader,
  CardTitle,
} from "@/components/ui/card"
import { StatusBadge } from "@/components/StatusBadge"
import type { Publication } from "@/types"

interface PublicationCardProps {
  publication: Publication
  onClick: () => void
}

const platformColors: Record<string, string> = {
  facebook: "bg-blue-100 text-blue-800",
  instagram: "bg-pink-100 text-pink-800",
  tiktok: "bg-slate-100 text-slate-800",
}

export function PublicationCard({ publication, onClick }: PublicationCardProps) {
  return (
    <Card
      className="cursor-pointer transition-shadow hover:shadow-md overflow-hidden"
      onClick={onClick}
    >
      {/* Thumbnail */}
      <div className="relative h-40 bg-muted">
        {publication.imageUrl ? (
          <img
            src={publication.imageUrl}
            alt={publication.title}
            className="h-full w-full object-cover"
          />
        ) : (
          <div className="flex h-full w-full items-center justify-center">
            <ImageIcon className="h-10 w-10 text-muted-foreground" />
          </div>
        )}
      </div>

      <CardHeader className="pb-2">
        <div className="flex items-start justify-between gap-2">
          <CardTitle className="text-base line-clamp-1">
            {publication.title}
          </CardTitle>
          <StatusBadge status={publication.status} />
        </div>
        <div className="flex items-center gap-2">
          <Badge className={platformColors[publication.platform]}>
            {publication.platform}
          </Badge>
          <span className="flex items-center gap-1 text-xs text-muted-foreground">
            <DollarSign className="h-3 w-3" />
            {publication.dailyBudget}/dia
          </span>
        </div>
      </CardHeader>

      <CardContent>
        <div className="grid grid-cols-3 gap-2 text-center text-xs">
          <div className="rounded-md bg-muted p-2">
            <Eye className="h-3 w-3 mx-auto mb-1 text-muted-foreground" />
            <p className="font-medium">{publication.impressions.toLocaleString()}</p>
            <p className="text-muted-foreground">Impresiones</p>
          </div>
          <div className="rounded-md bg-muted p-2">
            <MousePointer className="h-3 w-3 mx-auto mb-1 text-muted-foreground" />
            <p className="font-medium">{publication.clicks.toLocaleString()}</p>
            <p className="text-muted-foreground">Clicks</p>
          </div>
          <div className="rounded-md bg-muted p-2">
            <MessageCircle className="h-3 w-3 mx-auto mb-1 text-muted-foreground" />
            <p className="font-medium">{publication.whatsappConversations.toLocaleString()}</p>
            <p className="text-muted-foreground">WhatsApp</p>
          </div>
        </div>
      </CardContent>
    </Card>
  )
}
