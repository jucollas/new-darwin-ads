import { FileText } from "lucide-react"
import { Badge } from "@/components/ui/badge"
import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from "@/components/ui/card"
import { StatusBadge } from "@/components/StatusBadge"
import type { Campaign } from "@/types"

interface CampaignCardProps {
  campaign: Campaign
  onClick: () => void
}

export function CampaignCard({ campaign, onClick }: CampaignCardProps) {
  const formattedDate = new Date(campaign.createdAt).toLocaleDateString(
    "es-ES",
    {
      year: "numeric",
      month: "short",
      day: "numeric",
    }
  )

  return (
    <Card
      className="cursor-pointer transition-shadow hover:shadow-md"
      onClick={onClick}
    >
      <CardHeader className="pb-3">
        <div className="flex items-start justify-between">
          <CardTitle className="text-lg">{campaign.name}</CardTitle>
          <StatusBadge status={campaign.status === "active" ? "published" : campaign.status} />
        </div>
        <CardDescription className="line-clamp-2">
          {campaign.description}
        </CardDescription>
      </CardHeader>
      <CardContent>
        <div className="flex items-center justify-between text-sm text-muted-foreground">
          <div className="flex items-center gap-1">
            <FileText className="h-4 w-4" />
            <Badge variant="secondary">{campaign.publicationsCount} publicaciones</Badge>
          </div>
          <span>{formattedDate}</span>
        </div>
      </CardContent>
    </Card>
  )
}
