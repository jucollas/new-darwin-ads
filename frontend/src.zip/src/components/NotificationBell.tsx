import { useState, useRef, useEffect } from "react"
import { Bell } from "lucide-react"
import { useQuery } from "@tanstack/react-query"
import { cn } from "@/lib/utils"
import { useAuthStore } from "@/store/auth.store"
import api from "@/lib/api"
import type { Notification } from "@/types"

export function NotificationBell() {
  const [open, setOpen] = useState(false)
  const dropdownRef = useRef<HTMLDivElement>(null)
  const user = useAuthStore((s) => s.user)

  const { data: notifications = [] } = useQuery<Notification[]>({
    queryKey: ["notifications", user?.id],
    queryFn: async () => {
      const { data } = await api.get(`/api/notifications/${user!.id}`)
      return data
    },
    enabled: !!user?.id,
    refetchInterval: 30000,
  })

  const unreadCount = notifications.filter((n) => !n.read).length
  const latestFive = notifications.slice(0, 5)

  // Close dropdown when clicking outside
  useEffect(() => {
    const handleClickOutside = (e: MouseEvent) => {
      if (dropdownRef.current && !dropdownRef.current.contains(e.target as Node)) {
        setOpen(false)
      }
    }
    document.addEventListener("mousedown", handleClickOutside)
    return () => document.removeEventListener("mousedown", handleClickOutside)
  }, [])

  return (
    <div className="relative" ref={dropdownRef}>
      <button
        className="relative rounded-md p-2 hover:bg-accent transition-colors"
        onClick={() => setOpen(!open)}
        aria-label="Notificaciones"
      >
        <Bell className="h-5 w-5" />
        {unreadCount > 0 && (
          <span className="absolute right-1 top-1 h-2.5 w-2.5 rounded-full bg-red-500" />
        )}
      </button>

      {open && (
        <div className="absolute right-0 top-full mt-2 w-80 rounded-lg border bg-card shadow-lg z-50">
          <div className="p-3 border-b">
            <p className="text-sm font-semibold">Notificaciones</p>
          </div>
          {latestFive.length === 0 ? (
            <div className="p-4 text-center text-sm text-muted-foreground">
              No hay notificaciones
            </div>
          ) : (
            <ul className="max-h-72 overflow-y-auto">
              {latestFive.map((notification) => (
                <li
                  key={notification.id}
                  className={cn(
                    "border-b last:border-0 p-3 text-sm",
                    !notification.read && "bg-accent/50"
                  )}
                >
                  <p>{notification.message}</p>
                  <p className="text-xs text-muted-foreground mt-1">
                    {new Date(notification.createdAt).toLocaleDateString("es-ES", {
                      month: "short",
                      day: "numeric",
                      hour: "2-digit",
                      minute: "2-digit",
                    })}
                  </p>
                </li>
              ))}
            </ul>
          )}
        </div>
      )}
    </div>
  )
}
